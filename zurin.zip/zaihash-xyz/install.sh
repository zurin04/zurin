#!/bin/bash

# One-Click VPS Setup for Crypto Airdrop Platform
# This script installs everything needed to run the application on Ubuntu VPS

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Print functions
print_header() {
    echo -e "\n${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                    Crypto Airdrop Platform - VPS Setup                      ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}\n"
}

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root. Use: sudo bash install.sh"
        exit 1
    fi
}

# Update system
update_system() {
    print_status "Updating system packages..."
    apt update && apt upgrade -y
    apt install -y curl wget git unzip software-properties-common
}

# Install Node.js 20
install_nodejs() {
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt install -y nodejs
    
    # Verify installation
    node_version=$(node --version)
    npm_version=$(npm --version)
    print_status "Node.js installed: $node_version"
    print_status "npm installed: $npm_version"
}

# Install PostgreSQL
install_postgresql() {
    print_status "Installing PostgreSQL..."
    apt install -y postgresql postgresql-contrib
    
    # Start and enable PostgreSQL
    systemctl start postgresql
    systemctl enable postgresql
    
    print_status "PostgreSQL installed and started"
}

# Install Nginx
install_nginx() {
    print_status "Installing Nginx..."
    apt install -y nginx
    
    # Start and enable Nginx
    systemctl start nginx
    systemctl enable nginx
    
    print_status "Nginx installed and started"
}

# Install PM2 globally
install_pm2() {
    print_status "Installing PM2 process manager..."
    npm install -g pm2@latest
    
    # Setup PM2 startup
    pm2 startup systemd -u www-data --hp /var/www
    
    print_status "PM2 installed successfully"
}

# Configure firewall
setup_firewall() {
    print_status "Configuring firewall..."
    
    # Install and configure UFW
    apt install -y ufw
    
    # Reset UFW to defaults
    ufw --force reset
    
    # Set default policies
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH (keep current SSH connection alive)
    ufw allow 22/tcp
    
    # Allow HTTP and HTTPS
    ufw allow 80/tcp
    ufw allow 443/tcp
    
    # Enable firewall
    ufw --force enable
    
    print_status "Firewall configured successfully"
}

# Create application directory and user
setup_app_directory() {
    print_status "Setting up application directory..."
    
    # Create app directory
    mkdir -p /var/www/crypto-airdrop
    
    # Create www-data home directory if it doesn't exist
    mkdir -p /var/www
    
    # Set proper ownership
    chown -R www-data:www-data /var/www/crypto-airdrop
    chmod -R 755 /var/www/crypto-airdrop
    
    print_status "Application directory created at /var/www/crypto-airdrop"
}

# Setup database
setup_database() {
    print_status "Setting up PostgreSQL database..."
    
    # Generate secure password
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    DB_NAME="crypto_airdrop_db"
    DB_USER="crypto_app_user"
    
    # Create database and user
    sudo -u postgres psql << EOF
CREATE DATABASE ${DB_NAME};
CREATE USER ${DB_USER} WITH ENCRYPTED PASSWORD '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
ALTER USER ${DB_USER} CREATEDB;
\q
EOF

    # Store database credentials
    echo "DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}" > /var/www/crypto-airdrop/.env
    echo "NODE_ENV=production" >> /var/www/crypto-airdrop/.env
    echo "PORT=3000" >> /var/www/crypto-airdrop/.env
    echo "SESSION_SECRET=$(openssl rand -base64 32)" >> /var/www/crypto-airdrop/.env
    
    # Set proper permissions for .env file
    chown www-data:www-data /var/www/crypto-airdrop/.env
    chmod 600 /var/www/crypto-airdrop/.env
    
    print_status "Database created: ${DB_NAME}"
    print_status "Database user created: ${DB_USER}"
    print_status "Environment file created with secure credentials"
}

# Configure Nginx
setup_nginx() {
    print_status "Configuring Nginx reverse proxy..."
    
    # Create Nginx configuration
    cat > /etc/nginx/sites-available/crypto-airdrop << 'EOF'
server {
    listen 80;
    server_name _;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    
    # Main application
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # WebSocket support for chat
    location /socket.io/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        proxy_pass http://localhost:3000;
        expires 1y;
        add_header Cache-Control "public, immutable";
        proxy_set_header Host $host;
    }
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 10240;
    gzip_proxied any;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/xml+rss
        application/javascript
        application/json;
}
EOF

    # Enable the site
    ln -sf /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/
    rm -f /etc/nginx/sites-enabled/default
    
    # Test Nginx configuration
    if nginx -t; then
        systemctl reload nginx
        print_status "Nginx configured successfully"
    else
        print_error "Nginx configuration test failed"
        exit 1
    fi
}

# Create PM2 ecosystem file
create_pm2_config() {
    print_status "Creating PM2 configuration..."
    
    cat > /var/www/crypto-airdrop/ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'tsx',
    args: 'server/index.ts',
    cwd: '/var/www/crypto-airdrop',
    interpreter: 'node',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    time: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s',
    kill_timeout: 5000,
    wait_ready: true,
    listen_timeout: 10000
  }]
};
EOF

    chown www-data:www-data /var/www/crypto-airdrop/ecosystem.config.cjs
    
    print_status "PM2 configuration created"
}

# Create deployment script
create_deploy_script() {
    print_status "Creating deployment helper script..."
    
    cat > /var/www/crypto-airdrop/deploy.sh << 'EOF'
#!/bin/bash

# Deployment script for application updates
set -e

APP_DIR="/var/www/crypto-airdrop"
cd $APP_DIR

echo "Starting deployment..."

# Install dependencies
echo "Installing dependencies..."
sudo -u www-data npm install --production

# Build application
echo "Building application..."
sudo -u www-data npm run build

# Run database migrations
echo "Running database setup..."
sudo -u www-data npm run db:push
sudo -u www-data npm run db:seed

# Restart application
echo "Restarting application..."
sudo -u www-data pm2 reload ecosystem.config.cjs

echo "Deployment completed successfully!"
echo "Application is running at: http://$(curl -s ifconfig.me)"
EOF

    chmod +x /var/www/crypto-airdrop/deploy.sh
    chown www-data:www-data /var/www/crypto-airdrop/deploy.sh
    
    print_status "Deployment script created at /var/www/crypto-airdrop/deploy.sh"
}

# Create management scripts
create_management_scripts() {
    print_status "Creating management scripts..."
    
    # Status check script
    cat > /usr/local/bin/app-status << 'EOF'
#!/bin/bash
echo "=== Crypto Airdrop Platform Status ==="
echo ""
echo "Application Status:"
sudo -u www-data pm2 status
echo ""
echo "Nginx Status:"
systemctl status nginx --no-pager -l
echo ""
echo "Database Status:"
systemctl status postgresql --no-pager -l
echo ""
echo "Recent Logs:"
sudo -u www-data pm2 logs crypto-airdrop --lines 10
EOF

    # Restart script
    cat > /usr/local/bin/app-restart << 'EOF'
#!/bin/bash
echo "Restarting Crypto Airdrop Platform..."
sudo -u www-data pm2 restart crypto-airdrop
systemctl restart nginx
echo "Application restarted successfully!"
EOF

    # Logs script
    cat > /usr/local/bin/app-logs << 'EOF'
#!/bin/bash
sudo -u www-data pm2 logs crypto-airdrop
EOF

    # Make scripts executable
    chmod +x /usr/local/bin/app-status
    chmod +x /usr/local/bin/app-restart
    chmod +x /usr/local/bin/app-logs
    
    print_status "Management scripts created:"
    print_status "  - app-status: Check application status"
    print_status "  - app-restart: Restart the application"
    print_status "  - app-logs: View application logs"
}

# Create info file
create_info_file() {
    print_status "Creating setup information file..."
    
    SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || echo "Unable to detect")
    
    cat > /root/crypto-airdrop-setup.txt << EOF
Crypto Airdrop Platform - VPS Setup Complete
============================================
Setup Date: $(date)
Server IP: ${SERVER_IP}

Application Details:
- Directory: /var/www/crypto-airdrop
- User: www-data
- Port: 3000 (proxied through Nginx on port 80)
- URL: http://${SERVER_IP}

Database:
- Name: crypto_airdrop_db
- User: crypto_app_user
- Connection: Available in /var/www/crypto-airdrop/.env

Management Commands:
- Check status: app-status
- Restart app: app-restart  
- View logs: app-logs
- Deploy updates: cd /var/www/crypto-airdrop && ./deploy.sh

Next Steps:
1. Upload your application files to: /var/www/crypto-airdrop
2. Run: cd /var/www/crypto-airdrop && ./deploy.sh
3. Access your app at: http://${SERVER_IP}

Security Notes:
- Firewall configured (ports 22, 80, 443 open)
- SSL setup: Run 'certbot --nginx' after setting up domain
- Database credentials stored securely in .env file

Support:
- All services configured to start automatically on boot
- PM2 manages the Node.js application process
- Nginx handles reverse proxy and static files
- PostgreSQL database ready for use
EOF

    print_status "Setup information saved to /root/crypto-airdrop-setup.txt"
}

# Main installation function
main() {
    print_header
    
    echo "This script will install and configure:"
    echo "✓ Node.js 20 with npm"
    echo "✓ PostgreSQL database"
    echo "✓ Nginx web server"
    echo "✓ PM2 process manager"
    echo "✓ Firewall (UFW) security"
    echo "✓ Application directory and permissions"
    echo "✓ Auto-startup configuration"
    echo ""
    
    read -p "Continue with installation? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_warning "Installation cancelled"
        exit 1
    fi
    
    print_status "Starting VPS setup..."
    
    check_root
    update_system
    install_nodejs
    install_postgresql
    install_nginx
    install_pm2
    setup_firewall
    setup_app_directory
    setup_database
    setup_nginx
    create_pm2_config
    create_deploy_script
    create_management_scripts
    create_info_file
    
    print_header
    print_status "VPS setup completed successfully!"
    print_status ""
    print_status "Next steps:"
    print_status "1. Upload your application files to: /var/www/crypto-airdrop"
    print_status "2. Run deployment: cd /var/www/crypto-airdrop && ./deploy.sh"
    print_status "3. Access your application at: http://$(curl -s ifconfig.me 2>/dev/null || echo 'YOUR-SERVER-IP')"
    print_status ""
    print_status "Setup details saved in: /root/crypto-airdrop-setup.txt"
    print_status "Use 'app-status' to check application status anytime"
    
    echo -e "\n${GREEN}🎉 Your VPS is ready for the Crypto Airdrop Platform!${NC}\n"
}

# Run main function
main "$@"