import { ReactNode } from "react";
import Header from "./header";
import { Helmet } from "react-helmet";
import { useQuery } from "@tanstack/react-query";
import { SiteSettings } from "@shared/schema";

interface MainLayoutProps {
  children: ReactNode;
  title?: string;
}

export default function MainLayout({ children, title }: MainLayoutProps) {
  // Fetch site settings for dynamic branding
  const { data: siteSettings } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
  });
  
  const siteName = siteSettings?.site_name || "AirdropHub";
  const pageTitle = title ? `${title} - ${siteName}` : siteName;
  
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>{pageTitle}</title>
      </Helmet>
      <Header />
      <main className="flex-1 container mx-auto py-6 px-4 md:px-6">
        {children}
      </main>
    </div>
  );
}