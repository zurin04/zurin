import { createContext, useState, useContext, ReactNode } from 'react';
import { FloatingChat } from '@/components/chat/floating-chat';

interface GlobalChatContextType {
  isEnabled: boolean;
  enableChat: () => void;
  disableChat: () => void;
  toggleChat: () => void;
}

const GlobalChatContext = createContext<GlobalChatContextType | undefined>(undefined);

export function GlobalChatProvider({ children }: { children: ReactNode }) {
  const [isEnabled, setIsEnabled] = useState(true);

  const enableChat = () => setIsEnabled(true);
  const disableChat = () => setIsEnabled(false);
  const toggleChat = () => setIsEnabled(prev => !prev);

  return (
    <GlobalChatContext.Provider value={{ isEnabled, enableChat, disableChat, toggleChat }}>
      {children}
      {isEnabled && <FloatingChat />}
    </GlobalChatContext.Provider>
  );
}

export function useGlobalChat() {
  const context = useContext(GlobalChatContext);
  if (context === undefined) {
    throw new Error('useGlobalChat must be used within a GlobalChatProvider');
  }
  return context;
}