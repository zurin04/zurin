# Crypto Airdrop Platform

A comprehensive cryptocurrency airdrop discovery and engagement platform that helps users find, learn about, and participate in crypto airdrops.

## Features

- **User Management**: Registration with username/password or Web3 wallet connection
- **Airdrop Discovery**: Browse and search cryptocurrency airdrops by category
- **Creator System**: Apply to become a creator and manage airdrop content
- **Real-time Chat**: Global chat system with WebSocket support
- **Admin Dashboard**: Complete platform management tools
- **Crypto Prices**: Live cryptocurrency price tracking
- **Newsletter**: Email subscription system

## Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Passport.js + Web3 wallet support
- **Real-time**: WebSocket for chat functionality
- **UI**: Tailwind CSS + shadcn/ui components

## One-Click VPS Deployment

This project includes a complete one-click setup script for Ubuntu VPS deployment.

### Requirements

- Ubuntu 20.04+ VPS with root access
- At least 2GB RAM and 20GB disk space
- Public IP address

### Installation

1. **Download and run the setup script:**
   ```bash
   wget https://raw.githubusercontent.com/yourusername/crypto-airdrop-platform/main/install.sh
   sudo bash install.sh
   ```

2. **Upload your application files:**
   ```bash
   # Upload files to your VPS (replace with your server details)
   scp -r * user@your-server-ip:/tmp/app-files/
   
   # Move files to application directory
   sudo cp -r /tmp/app-files/* /var/www/crypto-airdrop/
   sudo chown -R www-data:www-data /var/www/crypto-airdrop/
   ```

3. **Deploy the application:**
   ```bash
   cd /var/www/crypto-airdrop
   sudo ./deploy.sh
   ```

4. **Access your application:**
   Visit `http://your-server-ip` in your browser

### What the Setup Script Does

The `install.sh` script automatically:

- Updates the system and installs dependencies
- Installs Node.js 20, PostgreSQL, Nginx, and PM2
- Configures firewall security (UFW)
- Creates PostgreSQL database with secure credentials
- Sets up Nginx reverse proxy with WebSocket support
- Configures PM2 for process management
- Creates management scripts for easy maintenance
- Sets up auto-startup for all services

### Management Commands

After installation, use these commands to manage your application:

```bash
# Check application status
app-status

# Restart the application
app-restart

# View application logs
app-logs

# Deploy updates
cd /var/www/crypto-airdrop && ./deploy.sh
```

### SSL Setup (Optional)

To enable HTTPS with Let's Encrypt:

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get SSL certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com
```

## Development

### Local Development

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd crypto-airdrop-platform
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Set up environment variables:**
   ```bash
   # DATABASE_URL is automatically set up in Replit
   # For local development, set up your PostgreSQL database
   ```

4. **Run database setup:**
   ```bash
   npm run db:push
   npm run db:seed
   ```

5. **Start development server:**
   ```bash
   npm run dev
   ```

### Project Structure

```
├── client/           # React frontend application
├── server/           # Express.js backend API
├── shared/           # Shared types and schemas
├── db/               # Database configuration and seeding
├── public/           # Static assets
├── install.sh        # One-click VPS setup script
└── README.md         # This file
```

## Configuration

### Environment Variables

The application uses these environment variables:

- `DATABASE_URL` - PostgreSQL connection string
- `NODE_ENV` - Environment (development/production)
- `PORT` - Server port (default: 3000)
- `SESSION_SECRET` - Session encryption key

### Database Schema

The application uses Drizzle ORM with PostgreSQL. Key tables:

- `users` - User accounts and authentication
- `airdrops` - Cryptocurrency airdrop listings
- `categories` - Airdrop categories
- `newsletters` - Email subscriptions
- `creator_applications` - Creator role applications

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `POST /api/auth/wallet-login` - Web3 wallet authentication

### Airdrops
- `GET /api/airdrops` - List all airdrops
- `GET /api/airdrops/:id` - Get specific airdrop
- `POST /api/airdrops` - Create new airdrop (creators/admins)
- `PUT /api/airdrops/:id` - Update airdrop (creators/admins)
- `DELETE /api/airdrops/:id` - Delete airdrop (admins)

### Admin
- `GET /api/admin/users` - List all users (admins)
- `PUT /api/admin/users/:id/promote` - Promote user to creator (admins)
- `GET /api/admin/applications` - List creator applications (admins)

## Security Features

- HTTPS support with SSL certificates
- Firewall configuration (UFW)
- Session management with secure cookies
- SQL injection prevention with parameterized queries
- XSS protection with helmet middleware
- CSRF protection for forms
- Rate limiting on API endpoints

## Monitoring

The setup includes comprehensive monitoring:

- Application process monitoring with PM2
- Automatic restart on failures
- Log rotation and management
- Health check endpoints
- System resource monitoring

## Support

### Troubleshooting

1. **Application won't start:**
   ```bash
   app-status  # Check service status
   app-logs    # View error logs
   ```

2. **Database connection issues:**
   ```bash
   sudo systemctl status postgresql
   sudo -u postgres psql -l  # List databases
   ```

3. **Nginx issues:**
   ```bash
   sudo nginx -t          # Test configuration
   sudo systemctl status nginx
   ```

### File Locations

- Application: `/var/www/crypto-airdrop/`
- Environment: `/var/www/crypto-airdrop/.env`
- Nginx config: `/etc/nginx/sites-available/crypto-airdrop`
- Setup info: `/root/crypto-airdrop-setup.txt`

## License

MIT License - see LICENSE file for details.