# Crypto Airdrop Platform - Complete Replit Project Documentation

## Project Overview

A comprehensive crypto learning and engagement platform that empowers users to explore, learn, and participate in cryptocurrency ecosystems through advanced user management, creator application workflows, and role-based access controls.

### Tech Stack
- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Express.js + Node.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Passport.js + Web3 wallet integration (SIWE)
- **Styling**: Tailwind CSS + shadcn/ui components
- **Animations**: Framer Motion
- **Real-time**: WebSockets
- **Icons**: Lucide React + React Icons
- **Form Handling**: React Hook Form + Zod validation
- **State Management**: TanStack Query
- **Routing**: Wouter

## Core Features

### 🔐 Authentication System
- Traditional username/password authentication
- Web3 wallet connection with SIWE (Sign-In with Ethereum)
- Role-based access control (Admin, Creator, User)
- Session management with express-session

### 👥 User Management
- User registration and profile management
- Admin dashboard for user oversight
- Creator application system with payment verification
- Profile customization with bio, social handles, profile images

### 💰 Airdrop Management
- Create, edit, and manage crypto airdrops
- Category-based organization
- Featured airdrops system
- View tracking and analytics
- Task completion tracking per user

### 💬 Real-time Chat
- Global chat system with WebSocket support
- Admin moderation capabilities
- User role indicators in chat
- Connection status management

### 📊 Crypto Price Tracking
- Live cryptocurrency price feeds
- Market data integration
- Price change indicators
- Auto-refresh functionality

### 🎨 Modern UI/UX
- Responsive design for mobile, tablet, desktop
- Dark/light mode support
- Smooth animations and transitions
- Professional gradient backgrounds
- Accessible design patterns

### 📧 Newsletter System
- Email subscription management
- Admin newsletter subscriber overview
- Unique email validation

### ⚙️ Site Settings
- Configurable site metadata
- Social media links management
- Creator fee configuration
- Payment address settings

## File Structure

```
/
├── client/                          # Frontend React application
│   ├── src/
│   │   ├── components/             # Reusable UI components
│   │   │   ├── admin/             # Admin-specific components
│   │   │   │   ├── admin-dashboard.tsx
│   │   │   │   ├── category-management.tsx
│   │   │   │   ├── user-management.tsx
│   │   │   │   └── site-settings.tsx
│   │   │   ├── auth/              # Authentication components
│   │   │   │   ├── auth-forms.tsx
│   │   │   │   ├── login-form.tsx
│   │   │   │   ├── register-form.tsx
│   │   │   │   └── wallet-connect.tsx
│   │   │   ├── crypto/            # Crypto-related components
│   │   │   │   ├── crypto-tracker.tsx
│   │   │   │   └── price-card.tsx
│   │   │   ├── layout/            # Layout components
│   │   │   │   ├── footer.tsx
│   │   │   │   ├── header.tsx
│   │   │   │   ├── legal-header.tsx
│   │   │   │   ├── navbar.tsx
│   │   │   │   └── sidebar.tsx
│   │   │   ├── ui/                # shadcn/ui components
│   │   │   │   ├── accordion.tsx
│   │   │   │   ├── alert-dialog.tsx
│   │   │   │   ├── avatar.tsx
│   │   │   │   ├── badge.tsx
│   │   │   │   ├── button.tsx
│   │   │   │   ├── card.tsx
│   │   │   │   ├── checkbox.tsx
│   │   │   │   ├── dialog.tsx
│   │   │   │   ├── dropdown-menu.tsx
│   │   │   │   ├── form.tsx
│   │   │   │   ├── input.tsx
│   │   │   │   ├── label.tsx
│   │   │   │   ├── popover.tsx
│   │   │   │   ├── scroll-area.tsx
│   │   │   │   ├── select.tsx
│   │   │   │   ├── separator.tsx
│   │   │   │   ├── sheet.tsx
│   │   │   │   ├── switch.tsx
│   │   │   │   ├── table.tsx
│   │   │   │   ├── tabs.tsx
│   │   │   │   ├── textarea.tsx
│   │   │   │   ├── toast.tsx
│   │   │   │   ├── toaster.tsx
│   │   │   │   └── tooltip.tsx
│   │   │   ├── airdrop-card.tsx
│   │   │   ├── airdrop-form.tsx
│   │   │   ├── chat-widget.tsx
│   │   │   ├── feature-card.tsx
│   │   │   ├── featured-airdrops.tsx
│   │   │   ├── hero-section.tsx
│   │   │   ├── member-list.tsx
│   │   │   └── newsletter-signup.tsx
│   │   ├── hooks/                 # Custom React hooks
│   │   │   ├── use-auth.tsx       # Authentication state management
│   │   │   ├── use-chat.tsx       # Chat functionality
│   │   │   ├── use-crypto.tsx     # Crypto price data
│   │   │   ├── use-global-chat.tsx # Global chat state
│   │   │   ├── use-mobile.tsx     # Mobile detection
│   │   │   └── use-toast.ts       # Toast notifications
│   │   ├── lib/                   # Utility libraries
│   │   │   ├── admin-route.tsx    # Admin route protection
│   │   │   ├── protected-route.tsx # User route protection
│   │   │   ├── queryClient.ts     # TanStack Query setup
│   │   │   └── utils.ts           # Utility functions
│   │   ├── pages/                 # Application pages
│   │   │   ├── airdrop-details.tsx
│   │   │   ├── airdrops-page.tsx
│   │   │   ├── auth-page.tsx
│   │   │   ├── chat-page.tsx
│   │   │   ├── cookie-policy.tsx
│   │   │   ├── create-airdrop.tsx
│   │   │   ├── disclaimer.tsx
│   │   │   ├── home-page.tsx
│   │   │   ├── members-page.tsx
│   │   │   ├── not-found.tsx
│   │   │   └── privacy-policy.tsx
│   │   ├── App.tsx               # Main app component with routing
│   │   ├── index.css            # Global styles
│   │   └── main.tsx             # React app entry point
├── db/                           # Database configuration
│   ├── index.ts                 # Database connection setup
│   └── seed.ts                  # Database seeding script
├── server/                      # Backend Express application
│   ├── auth.ts                  # Authentication middleware
│   ├── crypto-api.ts           # Cryptocurrency API integration
│   ├── index.ts                # Server entry point
│   ├── routes.ts               # API routes definition
│   ├── storage.ts              # Database operations interface
│   └── vite.ts                 # Vite development server setup
├── shared/                     # Shared types and schemas
│   └── schema.ts               # Drizzle database schema
├── scripts/                    # Deployment scripts
│   └── one-click-deploy.sh     # Production deployment script
├── package.json                # Dependencies and scripts
├── drizzle.config.ts          # Drizzle ORM configuration
├── tailwind.config.ts         # Tailwind CSS configuration
├── vite.config.ts             # Vite build configuration
├── postcss.config.js          # PostCSS configuration
└── tsconfig.json              # TypeScript configuration
```

## Database Schema

### Users Table
```sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password TEXT,
  wallet_address TEXT UNIQUE,
  nonce TEXT,
  is_admin BOOLEAN DEFAULT FALSE,
  is_creator BOOLEAN DEFAULT FALSE,
  bio TEXT,
  saved_tasks JSONB DEFAULT '[]',
  completed_tasks JSONB DEFAULT '[]',
  twitter_handle TEXT,
  discord_handle TEXT,
  telegram_handle TEXT,
  profile_image TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### Categories Table
```sql
CREATE TABLE categories (
  id SERIAL PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Airdrops Table
```sql
CREATE TABLE airdrops (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  tags JSONB DEFAULT '[]',
  link TEXT,
  potential_profit TEXT,
  status TEXT DEFAULT 'active',
  views INTEGER DEFAULT 0,
  category_id INTEGER REFERENCES categories(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  posted_by TEXT NOT NULL
);
```

### Site Settings Table
```sql
CREATE TABLE site_settings (
  id SERIAL PRIMARY KEY,
  site_name TEXT DEFAULT 'Crypto Airdrop Task Hub',
  site_description TEXT DEFAULT 'Discover and track crypto airdrops, tasks, and rewards.',
  logo_url TEXT,
  banner_url TEXT,
  twitter_link TEXT,
  discord_link TEXT,
  telegram_link TEXT,
  creator_fee_currency TEXT DEFAULT 'USDT',
  creator_fee_amount TEXT DEFAULT '10',
  creator_payment_address TEXT,
  creator_payment_network TEXT DEFAULT 'Ethereum Mainnet',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Creator Applications Table
```sql
CREATE TABLE creator_applications (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  status TEXT DEFAULT 'pending',
  reason TEXT,
  payment_tx_hash TEXT,
  payment_amount TEXT,
  payment_currency TEXT,
  reviewed_by INTEGER REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Newsletters Table
```sql
CREATE TABLE newsletters (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  subscribed_at TIMESTAMP DEFAULT NOW()
);
```

### Announcements Table
```sql
CREATE TABLE announcements (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  type TEXT DEFAULT 'info',
  is_active BOOLEAN DEFAULT TRUE,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  link TEXT,
  link_text TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/user` - Get current user
- `POST /api/auth/connect-wallet` - Connect Web3 wallet
- `POST /api/auth/wallet-login` - Login with wallet

### Users
- `GET /api/users` - Get all users (admin only)
- `PUT /api/users/:id` - Update user
- `POST /api/users/:id/promote-creator` - Promote to creator
- `POST /api/users/:id/revoke-creator` - Revoke creator status

### Airdrops
- `GET /api/airdrops` - Get all airdrops
- `GET /api/airdrops/featured` - Get featured airdrops
- `GET /api/airdrops/:id` - Get airdrop by ID
- `POST /api/airdrops` - Create airdrop
- `PUT /api/airdrops/:id` - Update airdrop
- `DELETE /api/airdrops/:id` - Delete airdrop
- `POST /api/airdrops/:id/views` - Increment views

### Categories
- `GET /api/categories` - Get all categories
- `POST /api/categories` - Create category (admin only)
- `PUT /api/categories/:id` - Update category (admin only)
- `DELETE /api/categories/:id` - Delete category (admin only)

### Crypto Prices
- `GET /api/crypto/prices` - Get cryptocurrency prices

### Site Settings
- `GET /api/site-settings` - Get site settings
- `PUT /api/site-settings` - Update site settings (admin only)

### Newsletter
- `POST /api/newsletter/subscribe` - Subscribe to newsletter
- `GET /api/newsletter/subscribers` - Get subscribers (admin only)

### Creator Applications
- `GET /api/creator-applications` - Get applications (admin only)
- `POST /api/creator-applications` - Submit application
- `PUT /api/creator-applications/:id` - Update application status

## Required Dependencies

### Main Dependencies
```json
{
  "@hookform/resolvers": "^3.9.1",
  "@neondatabase/serverless": "^0.10.4",
  "@radix-ui/react-*": "latest",
  "@tanstack/react-query": "^5.60.5",
  "axios": "^1.9.0",
  "bcrypt": "^5.1.1",
  "class-variance-authority": "^0.7.0",
  "clsx": "^2.1.1",
  "cmdk": "^1.0.0",
  "connect-pg-simple": "^10.0.0",
  "date-fns": "^3.6.0",
  "drizzle-orm": "^0.38.4",
  "drizzle-zod": "^0.6.0",
  "ethers": "^5.7.2",
  "express": "^4.21.2",
  "express-session": "^1.18.1",
  "framer-motion": "^11.18.2",
  "helmet": "^8.1.0",
  "lucide-react": "^0.453.0",
  "multer": "^1.4.5-lts.2",
  "passport": "^0.7.0",
  "passport-local": "^1.0.0",
  "pg": "^8.15.6",
  "react": "^18.3.1",
  "react-dom": "^18.3.1",
  "react-helmet": "^6.1.0",
  "react-hook-form": "^7.53.1",
  "react-icons": "^5.4.0",
  "recharts": "^2.13.0",
  "siwe": "^3.0.0",
  "tailwind-merge": "^2.5.4",
  "tailwindcss-animate": "^1.0.7",
  "wouter": "^3.3.5",
  "ws": "^8.18.0",
  "zod": "^3.23.8"
}
```

### Dev Dependencies
```json
{
  "@types/bcrypt": "^5.0.2",
  "@types/express": "4.17.21",
  "@types/express-session": "^1.18.0",
  "@types/multer": "^1.4.12",
  "@types/node": "20.16.11",
  "@types/passport": "^1.0.16",
  "@types/passport-local": "^1.0.38",
  "@types/react": "^18.3.11",
  "@types/react-dom": "^18.3.1",
  "@types/ws": "^8.5.13",
  "@vitejs/plugin-react": "^4.3.2",
  "autoprefixer": "^10.4.20",
  "drizzle-kit": "^0.27.1",
  "esbuild": "^0.24.0",
  "postcss": "^8.4.47",
  "tailwindcss": "^3.4.14",
  "tsx": "^4.19.4",
  "typescript": "5.6.3",
  "vite": "^5.4.9"
}
```

## Environment Variables

```env
# Database
DATABASE_URL=postgresql://username:password@host:port/database

# Session
SESSION_SECRET=your-super-secret-session-key

# Server
NODE_ENV=production
PORT=5000

# Optional: CoinGecko API (for crypto prices)
COINGECKO_API_KEY=your-api-key
```

## Setup Instructions for Replit

### 1. Create New Replit Project
1. Go to Replit.com
2. Create new project with Node.js template
3. Delete default files

### 2. Initialize Package.json
```json
{
  "name": "crypto-airdrop-platform",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "tsx server/index.ts",
    "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
    "start": "NODE_ENV=production node dist/index.js",
    "db:push": "drizzle-kit push --force --config=./drizzle.config.ts",
    "db:seed": "tsx db/seed.ts"
  }
}
```

### 3. Install Dependencies
Use Replit's package manager or run:
```bash
npm install [all dependencies listed above]
```

### 4. Database Setup
1. Create PostgreSQL database in Replit
2. Set DATABASE_URL environment variable
3. Run database migrations: `npm run db:push`
4. Seed database: `npm run db:seed`

### 5. Configuration Files

#### drizzle.config.ts
```typescript
import { defineConfig } from "drizzle-kit";

export default defineConfig({
  schema: "./shared/schema.ts",
  out: "./drizzle",
  dialect: "postgresql",
  dbCredentials: {
    url: process.env.DATABASE_URL!,
  },
});
```

#### vite.config.ts
```typescript
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./client/src"),
      "@shared": path.resolve(__dirname, "./shared"),
      "@db": path.resolve(__dirname, "./db"),
    },
  },
  root: "client",
  build: {
    outDir: "../dist",
    emptyOutDir: true,
  },
});
```

#### tailwind.config.ts
```typescript
import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./client/src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
```

### 6. Create Replit Configuration
Create `.replit` file:
```
run = "npm run dev"
modules = ["nodejs-20"]

[deployment]
run = ["sh", "-c", "npm run build && npm start"]
```

### 7. Global CSS (client/src/index.css)
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 224 71.4% 4.1%;
    --card: 0 0% 100%;
    --card-foreground: 224 71.4% 4.1%;
    --popover: 0 0% 100%;
    --popover-foreground: 224 71.4% 4.1%;
    --primary: 220.9 39.3% 11%;
    --primary-foreground: 210 20% 98%;
    --secondary: 220 14.3% 95.9%;
    --secondary-foreground: 220.9 39.3% 11%;
    --muted: 220 14.3% 95.9%;
    --muted-foreground: 220 8.9% 46.1%;
    --accent: 220 14.3% 95.9%;
    --accent-foreground: 220.9 39.3% 11%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 210 20% 98%;
    --border: 220 13% 91%;
    --input: 220 13% 91%;
    --ring: 224 71.4% 4.1%;
    --radius: 0.5rem;
  }

  .dark {
    --background: 224 71.4% 4.1%;
    --foreground: 210 20% 98%;
    --card: 224 71.4% 4.1%;
    --card-foreground: 210 20% 98%;
    --popover: 224 71.4% 4.1%;
    --popover-foreground: 210 20% 98%;
    --primary: 210 20% 98%;
    --primary-foreground: 220.9 39.3% 11%;
    --secondary: 215 27.9% 16.9%;
    --secondary-foreground: 210 20% 98%;
    --muted: 215 27.9% 16.9%;
    --muted-foreground: 217.9 10.6% 64.9%;
    --accent: 215 27.9% 16.9%;
    --accent-foreground: 210 20% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 20% 98%;
    --border: 215 27.9% 16.9%;
    --input: 215 27.9% 16.9%;
    --ring: 216 12.2% 83.9%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
  }
}

/* Custom gradient backgrounds */
.gradient-bg {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.gradient-bg-2 {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.gradient-bg-3 {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}
```

## Default Data Seeding

The database comes pre-seeded with:
- Admin user (username: admin, password: admin123)
- Demo user (username: demo, password: demo123)
- 5 default categories (DeFi, GameFi, Mining, Social, Trading)
- Sample airdrops
- Default site settings

## Security Features

1. **Authentication**: Passport.js with session management
2. **Password Hashing**: bcrypt for secure password storage
3. **CORS Protection**: Configured for production
4. **Helmet**: Security headers
5. **Input Validation**: Zod schemas for all inputs
6. **Role-based Access**: Admin/Creator/User permissions
7. **Session Security**: Secure session configuration

## Deployment Features

1. **One-click deployment script** for production servers
2. **PM2 process management** for production (fixed ES module compatibility)
3. **Nginx configuration** for reverse proxy
4. **SSL support** with Let's Encrypt
5. **Database migrations** with Drizzle
6. **Environment configuration** management

### PM2 Configuration (Fixed)

The deployment uses a `.cjs` file to avoid ES module conflicts:

```javascript
// ecosystem.config.cjs
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'tsx',
    args: 'server/index.ts',
    cwd: '/var/www/crypto-airdrop',
    interpreter: 'node',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: 'postgresql://user:pass@localhost:5432/db'
    },
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    time: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s'
  }]
};
```

**Key Fixes Applied:**
- Changed from `.js` to `.cjs` extension for CommonJS compatibility
- Updated script from `npx tsx` to direct `tsx` executable
- Added global tsx installation in deployment script
- Added proper interpreter specification

## Real-time Features

1. **WebSocket chat system** with admin moderation
2. **Live crypto price updates** (1-minute intervals)
3. **Real-time user status** in chat
4. **Connection monitoring** and auto-reconnection

## Admin Features

1. **User management dashboard**
2. **Category management**
3. **Site settings configuration**
4. **Creator application review**
5. **Newsletter subscriber management**
6. **Analytics and metrics**

## Mobile Responsiveness

- Fully responsive design
- Touch-friendly interfaces
- Mobile-optimized navigation
- Progressive Web App ready

## Performance Optimizations

1. **TanStack Query** for data caching
2. **Lazy loading** for components
3. **Image optimization** with proper sizing
4. **Bundle splitting** with Vite
5. **CSS-in-JS** with Tailwind for minimal CSS

## Getting Started

1. Clone this documentation into a new Replit project
2. Install all dependencies listed above
3. Set up PostgreSQL database
4. Configure environment variables
5. Run database migrations and seeding
6. Start development server with `npm run dev`
7. Access admin panel with default admin credentials
8. Customize site settings and branding

## Customization Points

1. **Branding**: Update site settings, colors, and logos
2. **Categories**: Add/modify airdrop categories
3. **Payment Integration**: Configure creator payment addresses
4. **Social Links**: Update footer and header social links
5. **Crypto Prices**: Modify tracked cryptocurrencies
6. **Chat Moderation**: Configure admin controls
7. **Email Integration**: Set up newsletter services

This documentation provides everything needed to recreate the entire crypto airdrop platform on Replit with full functionality and production readiness.