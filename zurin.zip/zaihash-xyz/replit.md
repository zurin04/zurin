# Crypto Airdrop Platform

## Overview

This is a comprehensive cryptocurrency airdrop discovery and engagement platform that helps users find, learn about, and participate in crypto airdrops. The platform features user management, creator applications, real-time chat, admin controls, and live crypto price tracking.

## System Architecture

The application follows a full-stack architecture with:

**Frontend**: React 18 with TypeScript, built using Vite for fast development and optimized production builds
**Backend**: Express.js server with TypeScript support
**Database**: PostgreSQL with Drizzle ORM for type-safe database operations
**Authentication**: Dual authentication system supporting traditional username/password and Web3 wallet connections
**Real-time Features**: WebSocket integration for live chat functionality
**Styling**: Tailwind CSS with shadcn/ui component library for consistent UI
**State Management**: TanStack Query for server state management
**Deployment**: Ubuntu server deployment with Nginx reverse proxy and PM2 process management

## Key Components

### Authentication System
- Traditional username/password authentication using Passport.js
- Web3 wallet integration with Sign-In with Ethereum (SIWE) protocol
- Role-based access control (Admin, Creator, User)
- Session management with express-session

### User Management
- User registration and profile management
- Creator application system with admin approval workflow
- Profile customization with social media handles and bio
- Image upload capabilities for profile pictures

### Airdrop Management
- CRUD operations for cryptocurrency airdrops
- Category-based organization system
- Featured airdrops functionality
- View tracking and analytics
- Rich text editor for airdrop descriptions with step-by-step tutorials

### Real-time Chat
- WebSocket-based global chat system
- Admin moderation capabilities
- User role indicators in chat interface
- Floating chat widget available site-wide
- Connection status monitoring

### Admin Dashboard
- Comprehensive admin panel for platform management
- User management with promotion/demotion capabilities
- Airdrop content moderation
- Category management
- Site settings configuration
- Newsletter subscriber management

## Data Flow

1. **User Registration/Login**: Users can register with username/password or connect Web3 wallets
2. **Content Discovery**: Users browse airdrops by category or search functionality
3. **Engagement**: Users can save airdrops, mark as completed, and participate in community chat
4. **Creator Workflow**: Users can apply to become creators, admins review applications
5. **Content Creation**: Approved creators and admins can create and manage airdrop content
6. **Real-time Communication**: WebSocket connections enable live chat across the platform

## External Dependencies

### Core Framework Dependencies
- **React 18** with TypeScript for frontend development
- **Express.js** for backend API server
- **PostgreSQL** database with Drizzle ORM
- **Vite** for build tooling and development server

### Authentication & Security
- **Passport.js** for authentication strategies
- **bcrypt** for password hashing
- **SIWE (Sign-In with Ethereum)** for Web3 authentication

### UI/UX Libraries
- **Tailwind CSS** for utility-first styling
- **shadcn/ui** for component library
- **Framer Motion** for animations
- **Lucide React** for icons

### Data Management
- **TanStack Query** for server state management
- **React Hook Form** with Zod validation
- **Axios** for HTTP requests

### Real-time Features
- **WebSocket (ws)** for chat functionality
- **Multer** for file uploads

### External APIs
- **CoinGecko API** for cryptocurrency price data

## Deployment Strategy

The application features a simplified, one-click VPS deployment system designed for users without deployment experience:

### One-Click VPS Setup
- **Single Script Installation**: `install.sh` handles complete system setup
- **Automated Configuration**: All services configured automatically
- **Zero Manual Setup**: No manual configuration files or complex commands
- **Production Ready**: Includes security, monitoring, and auto-startup

### What Gets Installed
- **Node.js 20** with npm package manager
- **PostgreSQL** database with secure credentials
- **Nginx** reverse proxy with WebSocket support
- **PM2** process manager for application monitoring
- **UFW Firewall** with security rules
- **Management Scripts** for easy maintenance

### Simple Deployment Process
1. Run `sudo bash install.sh` on Ubuntu VPS
2. Upload application files to `/var/www/crypto-airdrop`
3. Execute `sudo ./deploy.sh` to deploy
4. Access application at server IP address

### Management Commands
- `app-status` - Check application health
- `app-restart` - Restart all services
- `app-logs` - View application logs
- SSL setup with single certbot command

## Changelog

- June 14, 2025: Initial setup
- June 14, 2025: Simplified VPS deployment - Removed complex multi-script setup and created single `install.sh` script for one-click Ubuntu VPS deployment with automated configuration of all services

## User Preferences

Preferred communication style: Simple, everyday language.