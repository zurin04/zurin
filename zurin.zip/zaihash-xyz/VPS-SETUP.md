# VPS Setup - Quick Reference

## One Command Setup

```bash
sudo bash install.sh
```

## What You Get

✅ **Complete Working System**
- Node.js 20 + npm
- PostgreSQL database (auto-configured)
- Nginx web server (reverse proxy)
- PM2 process manager
- Firewall security
- SSL-ready configuration

✅ **Zero Configuration**
- Database credentials auto-generated
- All services auto-start on boot
- Security settings pre-configured
- Management commands ready

✅ **Easy Management**
- `app-status` - Check everything
- `app-restart` - Restart services
- `app-logs` - View logs
- `./deploy.sh` - Deploy updates

## After Setup

1. **Upload Files**
   ```bash
   scp -r * user@server-ip:/var/www/crypto-airdrop/
   ```

2. **Deploy**
   ```bash
   cd /var/www/crypto-airdrop
   sudo ./deploy.sh
   ```

3. **Access**
   Visit: `http://your-server-ip`

## Default Login

- **Admin User**: `admin` / `admin123`
- **Demo User**: `demo` / `demo123`

## File Locations

- App: `/var/www/crypto-airdrop/`
- Config: `/var/www/crypto-airdrop/.env`
- Setup Info: `/root/crypto-airdrop-setup.txt`

## SSL Setup

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

## Requirements

- Ubuntu 20.04+ VPS
- 2GB+ RAM
- Root access
- Public IP

That's it! The script handles everything else automatically.