# Easy VPS Deployment Guide

## Quick Setup (3 Steps Only)

### Step 1: Run Setup Script on Your VPS
```bash
# Connect to your Ubuntu VPS and run:
wget https://raw.githubusercontent.com/yourusername/crypto-airdrop-platform/main/install.sh
sudo bash install.sh
```

### Step 2: Upload Your Files
```bash
# From your local machine, upload files to VPS:
scp -r * user@your-server-ip:/tmp/app-files/

# Then on your VPS, move files:
sudo cp -r /tmp/app-files/* /var/www/crypto-airdrop/
sudo chown -R www-data:www-data /var/www/crypto-airdrop/
```

### Step 3: Deploy
```bash
# On your VPS:
cd /var/www/crypto-airdrop
sudo ./deploy.sh
```

That's it! Your app will be live at `http://your-server-ip`

## What Gets Installed Automatically

- Node.js 20 + npm
- PostgreSQL database (with secure password)
- Nginx web server (configured as reverse proxy)
- PM2 process manager (keeps your app running)
- Firewall security (only opens necessary ports)
- SSL support (ready for certificates)

## Easy Management

After setup, use these simple commands:

```bash
app-status    # Check if everything is running
app-restart   # Restart your application  
app-logs      # See what's happening
```

## Adding SSL (Optional)

```bash
# Install certificate tool
sudo apt install certbot python3-certbot-nginx

# Get free SSL certificate
sudo certbot --nginx -d yourdomain.com
```

## Troubleshooting

**App won't start?**
```bash
app-status
app-logs
```

**Need to update your app?**
```bash
# Upload new files, then:
cd /var/www/crypto-airdrop
sudo ./deploy.sh
```

**Database issues?**
```bash
sudo systemctl status postgresql
```

## File Locations

- Your app: `/var/www/crypto-airdrop/`
- Settings: `/var/www/crypto-airdrop/.env`
- Setup info: `/root/crypto-airdrop-setup.txt`

The setup script creates everything you need automatically - no manual configuration required!