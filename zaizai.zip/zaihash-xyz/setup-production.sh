#!/bin/bash

# Master One-Click Production Setup for Crypto Airdrop Platform
# This script orchestrates the complete production deployment process

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

print_banner() {
    clear
    echo -e "${PURPLE}"
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                                                                              ║"
    echo "║                 🚀 CRYPTO AIRDROP PLATFORM 🚀                               ║"
    echo "║                    Master Production Setup                                   ║"
    echo "║                                                                              ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    echo -e "${BLUE}One-Click Production Deployment for Ubuntu 20.04/22.04 LTS${NC}"
    echo ""
    echo "This will completely set up your production environment:"
    echo ""
    echo "✓ System Dependencies (Node.js, PostgreSQL, Nginx, PM2)"
    echo "✓ Security Configuration (Firewall, Headers, Permissions)"
    echo "✓ Database Setup (Schema, Users, Credentials)"
    echo "✓ Web Server (Reverse Proxy, Rate Limiting, Caching)"
    echo "✓ Process Management (PM2, Systemd Services)"
    echo "✓ Monitoring & Logging (Health Checks, Log Rotation)"
    echo "✓ Backup System (Automated Database & File Backups)"
    echo "✓ Application Deployment (Build, Deploy, Start)"
    echo "✓ Optional SSL Setup (Let's Encrypt Integration)"
    echo ""
    echo -e "${GREEN}Estimated setup time: 5-10 minutes${NC}"
    echo ""
}

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_prerequisites() {
    print_status "Checking prerequisites..."
    
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root. Use: sudo $0"
        exit 1
    fi
    
    # Check OS
    if [[ ! -f /etc/os-release ]]; then
        print_error "Cannot detect operating system"
        exit 1
    fi
    
    . /etc/os-release
    if [[ $NAME != *"Ubuntu"* ]]; then
        print_error "This script is designed for Ubuntu 20.04/22.04 LTS"
        print_error "Detected: $NAME $VERSION_ID"
        exit 1
    fi
    
    # Check if required files exist
    local required_scripts=("production-setup.sh" "deploy-app.sh" "health-check.sh")
    for script in "${required_scripts[@]}"; do
        if [[ ! -f "$script" ]]; then
            print_error "Required script not found: $script"
            exit 1
        fi
    done
    
    print_status "Prerequisites validated - Ubuntu $VERSION_ID detected"
}

run_production_setup() {
    print_status "Running production environment setup..."
    echo ""
    
    if ! ./production-setup.sh; then
        print_error "Production setup failed"
        exit 1
    fi
    
    print_status "Production environment setup completed"
}

run_application_deployment() {
    print_status "Deploying application..."
    echo ""
    
    if ! ./deploy-app.sh; then
        print_error "Application deployment failed"
        exit 1
    fi
    
    print_status "Application deployment completed"
}

run_health_check() {
    print_status "Performing initial health check..."
    echo ""
    
    sleep 5  # Give services time to stabilize
    
    ./health-check.sh
    
    print_status "Health check completed"
}

setup_ssl_option() {
    echo ""
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                            SSL Certificate Setup                            ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Do you want to set up SSL with Let's Encrypt?"
    echo "This requires a domain name pointing to this server."
    echo ""
    
    read -p "Setup SSL now? (y/N): " setup_ssl
    
    if [[ $setup_ssl =~ ^[Yy]$ ]]; then
        echo ""
        read -p "Enter your domain name (e.g., yourdomain.com): " domain
        read -p "Enter your email address: " email
        
        if [[ -n "$domain" && -n "$email" ]]; then
            print_status "Setting up SSL for $domain..."
            if ./ssl-setup.sh "$domain" "$email"; then
                print_status "SSL setup completed successfully"
            else
                print_warning "SSL setup failed - you can run it later with:"
                print_warning "sudo ./ssl-setup.sh $domain $email"
            fi
        else
            print_warning "Domain or email not provided - skipping SSL setup"
        fi
    else
        print_status "SSL setup skipped - you can run it later with:"
        print_status "sudo ./ssl-setup.sh yourdomain.com admin@yourdomain.com"
    fi
}

show_completion_summary() {
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                        🎉 DEPLOYMENT COMPLETE! 🎉                           ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # Get server IP
    local server_ip=$(curl -s ifconfig.me 2>/dev/null || echo "YOUR_SERVER_IP")
    
    echo -e "${BLUE}Your Crypto Airdrop Platform is now live!${NC}"
    echo ""
    echo "🌐 Access URLs:"
    echo "   • HTTP: http://$server_ip"
    echo "   • Local: http://localhost"
    
    # Check if SSL was configured
    local ssl_configured=false
    for cert_dir in /etc/letsencrypt/live/*/; do
        if [[ -d "$cert_dir" && -f "${cert_dir}cert.pem" ]]; then
            ssl_configured=true
            local domain=$(basename "$cert_dir")
            echo "   • HTTPS: https://$domain"
            break
        fi
    done
    
    echo ""
    echo "📊 System Status:"
    sudo -u www-data pm2 list 2>/dev/null | head -3
    
    echo ""
    echo "🔧 Management Commands:"
    echo "   • Health Check: sudo ./health-check.sh"
    echo "   • View Logs: sudo -u www-data pm2 logs crypto-airdrop"
    echo "   • Restart App: sudo -u www-data pm2 restart crypto-airdrop"
    echo "   • System Monitor: sudo crypto-airdrop-monitor.sh"
    
    echo ""
    echo "📁 Important Files:"
    echo "   • App Directory: /var/www/crypto-airdrop/"
    echo "   • Configuration: /root/deployment-info.txt"
    echo "   • Environment: /var/www/crypto-airdrop/.env"
    echo "   • Logs: /var/log/crypto-airdrop/"
    
    echo ""
    echo "🔒 Security Reminders:"
    echo "   • Change admin password after first login"
    echo "   • Review firewall settings: sudo ufw status"
    echo "   • Monitor system regularly: sudo ./health-check.sh"
    
    if [[ "$ssl_configured" == false ]]; then
        echo "   • Setup SSL when ready: sudo ./ssl-setup.sh domain.com email@domain.com"
    fi
    
    echo ""
    echo "📖 Documentation:"
    echo "   • Quick Start Guide: ./PRODUCTION-QUICKSTART.md"
    echo "   • Deployment Details: /root/deployment-info.txt"
    echo ""
    echo -e "${GREEN}Your crypto airdrop platform is ready for production use!${NC}"
}

cleanup_temp_files() {
    # Clean up any temporary files
    rm -f /tmp/health_check_output 2>/dev/null || true
}

main() {
    print_banner
    
    # Confirmation prompt
    echo -e "${YELLOW}⚠️  This will install and configure production services on this server.${NC}"
    echo ""
    read -p "Continue with complete production setup? (y/N): " confirm
    
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        echo "Setup cancelled."
        exit 0
    fi
    
    echo ""
    print_status "Starting complete production deployment..."
    echo ""
    
    # Setup phases
    check_prerequisites
    run_production_setup
    run_application_deployment
    run_health_check
    setup_ssl_option
    cleanup_temp_files
    show_completion_summary
    
    echo ""
    print_status "Master setup completed successfully!"
}

# Handle script interruption
trap 'echo -e "\n${RED}Setup interrupted!${NC}"; cleanup_temp_files; exit 1' INT TERM

main "$@"