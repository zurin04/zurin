#!/bin/bash

# One-Click Production Setup for Crypto Airdrop Platform
# Ubuntu 20.04/22.04 LTS Compatible
# Author: Automated Production Setup
# Version: 1.0

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="crypto-airdrop"
APP_DIR="/var/www/${APP_NAME}"
DB_NAME="crypto_airdrop_db"
DB_USER="crypto_user"
DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
DOMAIN="localhost"
NODE_VERSION="20"

print_banner() {
    clear
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                 🚀 Crypto Airdrop Platform Setup 🚀                         ║"
    echo "║                     One-Click Production Deployment                          ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    echo "This will install and configure everything needed for production:"
    echo "• Node.js ${NODE_VERSION}, PostgreSQL, Nginx, PM2"
    echo "• Database setup with secure credentials"
    echo "• Firewall and security configuration"  
    echo "• SSL-ready web server with rate limiting"
    echo "• Process monitoring and auto-restart"
    echo "• Complete application deployment"
    echo ""
}

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root. Use: sudo $0"
        exit 1
    fi
}

detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
    else
        print_error "Cannot detect OS version"
        exit 1
    fi
    
    if [[ $OS != *"Ubuntu"* ]]; then
        print_error "This script is designed for Ubuntu 20.04/22.04 LTS"
        exit 1
    fi
    
    print_status "Detected: $OS $VER"
}

update_system() {
    print_status "Updating system packages..."
    apt update && apt upgrade -y
    apt install -y curl wget gnupg2 software-properties-common apt-transport-https ca-certificates lsb-release
}

install_nodejs() {
    print_status "Installing Node.js ${NODE_VERSION}..."
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
    apt install -y nodejs
    
    # Install global packages
    npm install -g pm2 tsx
    
    print_status "Node.js $(node --version) installed"
    print_status "NPM $(npm --version) installed"
}

install_postgresql() {
    print_status "Installing and configuring PostgreSQL..."
    apt install -y postgresql postgresql-contrib
    
    # Start and enable PostgreSQL
    systemctl start postgresql
    systemctl enable postgresql
    
    # Create database and user
    sudo -u postgres psql << EOF
CREATE DATABASE ${DB_NAME};
CREATE USER ${DB_USER} WITH ENCRYPTED PASSWORD '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
ALTER USER ${DB_USER} CREATEDB;
\q
EOF
    
    print_status "PostgreSQL configured with database: ${DB_NAME}"
}

install_nginx() {
    print_status "Installing and configuring Nginx..."
    apt install -y nginx
    
    # Remove default configuration
    rm -f /etc/nginx/sites-enabled/default
    
    # Create application configuration
    cat > /etc/nginx/sites-available/${APP_NAME} << 'EOF'
# Rate limiting zones
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
limit_req_zone $binary_remote_addr zone=general:10m rate=30r/s;

server {
    listen 80;
    server_name _;
    client_max_body_size 50M;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self' wss: ws:;" always;
    
    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        try_files $uri @proxy;
    }
    
    # API routes with rate limiting
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # WebSocket support
    location /ws {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 86400;
    }
    
    # All other requests
    location / {
        limit_req zone=general burst=50 nodelay;
        try_files $uri @proxy;
    }
    
    location @proxy {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF
    
    # Enable site
    ln -sf /etc/nginx/sites-available/${APP_NAME} /etc/nginx/sites-enabled/
    
    # Test and start Nginx
    nginx -t && systemctl restart nginx && systemctl enable nginx
    
    print_status "Nginx configured and started"
}

setup_firewall() {
    print_status "Configuring UFW firewall..."
    ufw --force reset
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow ssh
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw --force enable
    
    print_status "Firewall configured"
}

create_app_user() {
    print_status "Creating application user..."
    if ! id "www-data" &>/dev/null; then
        useradd -r -s /bin/false www-data
    fi
    
    # Create application directory
    mkdir -p ${APP_DIR}
    chown -R www-data:www-data ${APP_DIR}
    chmod -R 755 ${APP_DIR}
}

setup_environment() {
    print_status "Setting up environment configuration..."
    
    # Create environment file
    cat > ${APP_DIR}/.env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
SESSION_SECRET=$(openssl rand -base64 32)
PORT=3000
EOF
    
    chown www-data:www-data ${APP_DIR}/.env
    chmod 600 ${APP_DIR}/.env
}

create_pm2_config() {
    print_status "Creating PM2 configuration..."
    
    cat > ${APP_DIR}/ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'server/index.js',
    cwd: '/var/www/crypto-airdrop',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    max_memory_restart: '512M',
    node_args: '--max-old-space-size=512',
    error_file: '/var/log/crypto-airdrop/error.log',
    out_file: '/var/log/crypto-airdrop/out.log',
    log_file: '/var/log/crypto-airdrop/combined.log',
    time: true,
    autorestart: true,
    watch: false,
    max_restarts: 10,
    min_uptime: '10s'
  }]
};
EOF
    
    chown www-data:www-data ${APP_DIR}/ecosystem.config.cjs
    
    # Create log directory
    mkdir -p /var/log/crypto-airdrop
    chown www-data:www-data /var/log/crypto-airdrop
}

create_systemd_service() {
    print_status "Creating systemd service..."
    
    cat > /etc/systemd/system/${APP_NAME}.service << EOF
[Unit]
Description=Crypto Airdrop Platform
After=network.target postgresql.service

[Service]
Type=forking
User=www-data
WorkingDirectory=${APP_DIR}
ExecStart=/usr/bin/pm2 start ecosystem.config.cjs --no-daemon
ExecReload=/usr/bin/pm2 restart crypto-airdrop
ExecStop=/usr/bin/pm2 stop crypto-airdrop
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable ${APP_NAME}
}

setup_logrotate() {
    print_status "Setting up log rotation..."
    
    cat > /etc/logrotate.d/${APP_NAME} << EOF
/var/log/crypto-airdrop/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    postrotate
        sudo -u www-data pm2 reloadLogs
    endscript
}
EOF
}

create_backup_script() {
    print_status "Creating backup script..."
    
    mkdir -p /var/backups/${APP_NAME}/{db,app}
    
    cat > /usr/local/bin/${APP_NAME}-backup.sh << EOF
#!/bin/bash
BACKUP_DIR="/var/backups/${APP_NAME}"
DATE=\$(date +%Y%m%d_%H%M%S)

# Database backup
sudo -u postgres pg_dump ${DB_NAME} | gzip > \${BACKUP_DIR}/db/${APP_NAME}_\${DATE}.sql.gz

# Application backup (excluding node_modules)
tar --exclude='node_modules' --exclude='.git' -czf \${BACKUP_DIR}/app/${APP_NAME}_\${DATE}.tar.gz -C ${APP_DIR} .

# Clean old backups (keep last 7 days)
find \${BACKUP_DIR}/db -name "*.sql.gz" -mtime +7 -delete
find \${BACKUP_DIR}/app -name "*.tar.gz" -mtime +7 -delete

echo "Backup completed: \${DATE}"
EOF
    
    chmod +x /usr/local/bin/${APP_NAME}-backup.sh
    
    # Add to crontab for weekly backups
    (crontab -l 2>/dev/null; echo "0 2 * * 0 /usr/local/bin/${APP_NAME}-backup.sh") | crontab -
}

create_monitoring_script() {
    print_status "Creating monitoring script..."
    
    cat > /usr/local/bin/${APP_NAME}-monitor.sh << 'EOF'
#!/bin/bash

echo "=== Crypto Airdrop Platform Status ==="
echo "Date: $(date)"
echo ""

echo "=== System Resources ==="
echo "Memory Usage:"
free -h
echo ""
echo "Disk Usage:"
df -h | grep -E '^/dev/'
echo ""
echo "Load Average:"
uptime
echo ""

echo "=== Application Status ==="
sudo -u www-data pm2 list
echo ""

echo "=== Database Status ==="
systemctl is-active postgresql && echo "PostgreSQL: Running" || echo "PostgreSQL: Stopped"
echo ""

echo "=== Web Server Status ==="
systemctl is-active nginx && echo "Nginx: Running" || echo "Nginx: Stopped"
nginx -t 2>/dev/null && echo "Nginx Config: Valid" || echo "Nginx Config: Invalid"
echo ""

echo "=== Network Status ==="
netstat -tlnp | grep -E ':80|:443|:3000'
echo ""

echo "=== Recent Errors ==="
echo "Application Errors (last 10):"
tail -10 /var/log/crypto-airdrop/error.log 2>/dev/null || echo "No error log found"
echo ""
echo "Nginx Errors (last 5):"
tail -5 /var/log/nginx/error.log 2>/dev/null || echo "No nginx errors"
EOF
    
    chmod +x /usr/local/bin/${APP_NAME}-monitor.sh
}

create_deployment_info() {
    print_status "Creating deployment information..."
    
    cat > /root/deployment-info.txt << EOF
Crypto Airdrop Platform - Production Deployment
===============================================
Deployment Date: $(date)
Server OS: $OS $VER
Node.js Version: $(node --version)
PM2 Version: $(pm2 --version)

=== Application Details ===
App Directory: ${APP_DIR}
App User: www-data
PM2 Config: ${APP_DIR}/ecosystem.config.cjs
Environment: ${APP_DIR}/.env

=== Database Details ===
Database Name: ${DB_NAME}
Database User: ${DB_USER}
Database Password: ${DB_PASSWORD}
Connection String: postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}

=== Web Server ===
Nginx Config: /etc/nginx/sites-available/${APP_NAME}
Document Root: ${APP_DIR}
Listen Port: 80 (HTTP), 443 (HTTPS ready)

=== File Locations ===
Application: ${APP_DIR}/
Logs: /var/log/crypto-airdrop/
Backups: /var/backups/${APP_NAME}/
Nginx Config: /etc/nginx/sites-available/${APP_NAME}

=== Management Commands ===
# Application Management
sudo systemctl start ${APP_NAME}        # Start application
sudo systemctl stop ${APP_NAME}         # Stop application  
sudo systemctl restart ${APP_NAME}      # Restart application
sudo systemctl status ${APP_NAME}       # Check status

# PM2 Management (as www-data user)
sudo -u www-data pm2 list              # List processes
sudo -u www-data pm2 logs crypto-airdrop # View logs
sudo -u www-data pm2 restart crypto-airdrop # Restart app
sudo -u www-data pm2 monit             # Monitor resources

# Database Management
sudo -u postgres psql -d ${DB_NAME}    # Connect to database
sudo systemctl restart postgresql      # Restart PostgreSQL

# Web Server Management  
sudo systemctl restart nginx           # Restart Nginx
sudo nginx -t                          # Test Nginx config
sudo systemctl reload nginx            # Reload Nginx config

# Monitoring & Maintenance
sudo ${APP_NAME}-monitor.sh             # System status
sudo ${APP_NAME}-backup.sh              # Manual backup
sudo ufw status                         # Firewall status

=== Deployment Steps ===
1. Copy your application files to ${APP_DIR}
2. Install dependencies: sudo -u www-data npm install --production
3. Build application: sudo -u www-data npm run build  
4. Setup database: sudo -u www-data npm run db:push
5. Seed database: sudo -u www-data npm run db:seed
6. Start application: sudo systemctl start ${APP_NAME}

=== Security Notes ===
- Change default admin password after first login
- Setup SSL with Let's Encrypt: sudo certbot --nginx
- Review firewall rules: sudo ufw status
- Monitor logs regularly for security issues
- Keep system packages updated

=== Troubleshooting ===
- View application logs: sudo -u www-data pm2 logs crypto-airdrop
- Check system status: sudo ${APP_NAME}-monitor.sh
- Database connection issues: Check ${APP_DIR}/.env
- Permission issues: sudo chown -R www-data:www-data ${APP_DIR}

Your crypto airdrop platform is ready for production!
EOF
    
    chmod 600 /root/deployment-info.txt
}

main() {
    print_banner
    
    read -p "Continue with production setup? (y/N): " confirm
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        echo "Setup cancelled."
        exit 0
    fi
    
    check_root
    detect_os
    
    print_status "Starting production setup..."
    
    update_system
    install_nodejs  
    install_postgresql
    install_nginx
    setup_firewall
    create_app_user
    setup_environment
    create_pm2_config
    create_systemd_service
    setup_logrotate
    create_backup_script
    create_monitoring_script
    create_deployment_info
    
    print_status "Production setup completed successfully!"
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                          🎉 Setup Complete! 🎉                               ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Next steps:"
    echo "1. Copy your application files to ${APP_DIR}"
    echo "2. Run deployment script: ./deploy-app.sh"
    echo "3. Check deployment info: cat /root/deployment-info.txt"
    echo ""
    echo "Your server is ready for the crypto airdrop platform!"
}

main "$@"