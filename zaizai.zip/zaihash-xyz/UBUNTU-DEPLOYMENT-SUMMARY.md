# Ubuntu VPS Deployment Summary

## What's Been Prepared for Your Ubuntu Server

Your crypto airdrop platform is now optimized for Ubuntu server deployment with production-grade configurations:

### 🔧 Core Infrastructure Files Created

**Production Configuration:**
- `ecosystem.config.js` - PM2 process manager configuration
- `.env.production` - Production environment template
- `deploy.sh` - Complete Ubuntu server setup script
- `deploy-update.sh` - Application update automation
- `README-UBUNTU-DEPLOYMENT.md` - Comprehensive deployment guide

**Monitoring & Maintenance:**
- `server-monitor.sh` - System health monitoring script
- `health-check.js` - Application health checker
- `logrotate.conf` - Log rotation configuration
- Health endpoints: `/health`, `/api/system/status`, `/api/system/metrics`

### 🚀 One-Command Deployment

Run this on your Ubuntu VPS as root:
```bash
curl -fsSL https://your-repo.com/deploy.sh | sudo bash
```

Or download and run manually:
```bash
wget https://your-repo.com/deploy.sh
chmod +x deploy.sh
sudo ./deploy.sh
```

### 📋 What the Deployment Script Does

1. **System Setup:**
   - Installs Node.js 20, PostgreSQL, Nginx, PM2
   - Configures firewall (UFW) with secure rules
   - Creates application directory `/var/www/crypto-airdrop`

2. **Database Configuration:**
   - Creates dedicated PostgreSQL database and user
   - Generates secure passwords automatically
   - Sets up proper permissions

3. **Web Server Setup:**
   - Configures Nginx with rate limiting and security headers
   - Sets up proxy to Node.js application
   - Includes WebSocket support for real-time chat

4. **Process Management:**
   - Creates systemd service for automatic startup
   - Configures PM2 for process monitoring
   - Sets up log rotation and monitoring

5. **Security Hardening:**
   - Firewall configuration
   - Security headers in Nginx
   - Secure file permissions

### 🔍 Production Optimizations Added

**Server Configuration:**
- Port flexibility (3000 for production, 5000 for development)
- Memory usage optimization with PM2
- Automatic restart on failures
- Health check endpoints for monitoring

**Database Optimizations:**
- Connection pooling with proper SSL settings
- Performance tuned PostgreSQL settings
- Automated backup system

**Monitoring & Logging:**
- Comprehensive system monitoring script
- Log rotation to prevent disk usage issues
- Health endpoints for external monitoring
- Performance metrics collection

### 📊 Health Monitoring Endpoints

Your application includes these monitoring endpoints:

1. **Simple Health Check:**
   ```
   GET /health
   Returns: "healthy" (200 OK)
   ```

2. **Detailed System Status:**
   ```
   GET /api/system/status
   Returns: JSON with database, services, memory usage
   ```

3. **System Metrics:**
   ```
   GET /api/system/metrics
   Returns: CPU, memory, uptime, connections
   ```

### 🔄 Update Process

To update your application on Ubuntu:
```bash
sudo ./deploy-update.sh
```

This script will:
- Create automatic backup
- Stop application safely
- Install new dependencies
- Build updated application
- Update database schema
- Restart with zero downtime

### 📈 Expected Performance on Ubuntu VPS

**Minimum Requirements:**
- 1 GB RAM (2 GB recommended)
- 1 CPU core (2 cores recommended)
- 20 GB disk space
- Ubuntu 20.04 LTS or newer

**Performance Expectations:**
- 100-500 concurrent users (depending on VPS specs)
- Sub-200ms API response times
- Real-time WebSocket chat support
- Automated scaling with PM2 cluster mode

### 🛡️ Security Features

**Built-in Security:**
- Rate limiting on API endpoints
- CORS protection
- SQL injection prevention with Drizzle ORM
- Secure session management
- Input validation on all endpoints

**Production Security:**
- Firewall rules (SSH + HTTP/HTTPS only)
- Security headers in Nginx
- Fail2ban integration (optional)
- SSL/TLS ready with Let's Encrypt support

### 📝 File Structure on Ubuntu Server

```
/var/www/crypto-airdrop/
├── dist/                    # Built application
├── node_modules/           # Dependencies
├── ecosystem.config.js     # PM2 configuration
├── .env                   # Environment variables
├── health-check.js        # Health monitoring
└── server-monitor.sh      # System monitoring

/var/log/pm2/              # Application logs
/var/backups/crypto-airdrop/ # Automatic backups
/etc/nginx/sites-available/crypto-airdrop # Nginx config
```

### 🔧 Management Commands

**Application Control:**
```bash
sudo systemctl start|stop|restart crypto-airdrop
sudo -u www-data pm2 status|logs|restart crypto-airdrop
```

**Database Management:**
```bash
sudo -u postgres psql -d crypto_airdrop_db
sudo -u postgres pg_dump crypto_airdrop_db > backup.sql
```

**Monitoring:**
```bash
sudo ./server-monitor.sh
curl http://localhost:3000/health
tail -f /var/log/pm2/crypto-airdrop.log
```

### 🚨 Common Issues & Solutions

**Application Won't Start:**
```bash
# Check logs
sudo journalctl -u crypto-airdrop -n 50
sudo -u www-data pm2 logs

# Verify environment
sudo -u www-data cat /var/www/crypto-airdrop/.env
```

**Database Connection Issues:**
```bash
# Test database
sudo -u postgres psql -d crypto_airdrop_db -c "SELECT 1;"

# Restart PostgreSQL
sudo systemctl restart postgresql
```

**High Resource Usage:**
```bash
# Monitor resources
htop
sudo -u www-data pm2 monit

# Restart with memory limit
sudo -u www-data pm2 restart crypto-airdrop --max-memory-restart 512M
```

### 🔄 Backup Strategy

**Automated Backups (Weekly):**
- Database dumps to `/var/backups/crypto-airdrop/db/`
- Application files to `/var/backups/crypto-airdrop/app/`
- Automatic cleanup of old backups

**Manual Backup:**
```bash
# Create immediate backup
sudo -u postgres pg_dump crypto_airdrop_db | gzip > backup_$(date +%Y%m%d).sql.gz
```

### 📞 Support & Maintenance

**Regular Tasks:**
- Monitor system resources weekly
- Check security logs monthly
- Update system packages as needed
- Review application logs for errors

**Getting Help:**
- View deployment info: `cat /root/deployment-info.txt`
- System status: `sudo ./server-monitor.sh`
- Application logs: `sudo -u www-data pm2 logs crypto-airdrop`

Your crypto airdrop platform is now ready for professional Ubuntu server deployment with enterprise-grade monitoring, security, and maintenance capabilities.