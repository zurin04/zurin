#!/bin/bash

# Health Check Script for Crypto Airdrop Platform
# This script performs comprehensive health checks for production monitoring

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

APP_NAME="crypto-airdrop"
APP_DIR="/var/www/${APP_NAME}"

print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

check_system_resources() {
    echo "=== System Resources ==="
    
    # Memory check
    local mem_usage=$(free | grep Mem | awk '{printf "%.1f", $3/$2 * 100.0}')
    if (( $(echo "$mem_usage > 80" | bc -l) )); then
        print_warning "Memory usage: ${mem_usage}% (High)"
    else
        print_status "Memory usage: ${mem_usage}%"
    fi
    
    # Disk space check
    local disk_usage=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
    if [[ $disk_usage -gt 80 ]]; then
        print_warning "Disk usage: ${disk_usage}% (High)"
    else
        print_status "Disk usage: ${disk_usage}%"
    fi
    
    # Load average
    local load_avg=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    print_info "Load average: $load_avg"
    
    echo ""
}

check_services() {
    echo "=== System Services ==="
    
    # PostgreSQL
    if systemctl is-active --quiet postgresql; then
        print_status "PostgreSQL: Running"
    else
        print_error "PostgreSQL: Stopped"
    fi
    
    # Nginx
    if systemctl is-active --quiet nginx; then
        print_status "Nginx: Running"
        if nginx -t 2>/dev/null; then
            print_status "Nginx Config: Valid"
        else
            print_error "Nginx Config: Invalid"
        fi
    else
        print_error "Nginx: Stopped"
    fi
    
    # Application service
    if systemctl is-active --quiet ${APP_NAME}; then
        print_status "App Service: Running"
    else
        print_warning "App Service: Stopped"
    fi
    
    echo ""
}

check_application() {
    echo "=== Application Status ==="
    
    # PM2 process check
    if sudo -u www-data pm2 list 2>/dev/null | grep -q "crypto-airdrop.*online"; then
        print_status "PM2 Process: Running"
        
        # Memory usage of PM2 process
        local pm2_mem=$(sudo -u www-data pm2 list | grep crypto-airdrop | awk '{print $8}')
        print_info "App Memory: $pm2_mem"
        
        # Uptime
        local uptime=$(sudo -u www-data pm2 list | grep crypto-airdrop | awk '{print $10}')
        print_info "App Uptime: $uptime"
        
    else
        print_error "PM2 Process: Not running"
    fi
    
    echo ""
}

check_network_connectivity() {
    echo "=== Network Connectivity ==="
    
    # Local application port
    if netstat -tlnp | grep -q ":3000"; then
        print_status "App Port 3000: Listening"
    else
        print_error "App Port 3000: Not listening"
    fi
    
    # HTTP response check
    local http_status=$(curl -s -o /dev/null -w "%{http_code}" http://localhost 2>/dev/null || echo "000")
    if [[ $http_status == "200" || $http_status == "302" ]]; then
        print_status "HTTP Response: $http_status"
    else
        print_error "HTTP Response: $http_status"
    fi
    
    # Application health endpoint (if exists)
    local app_status=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/health 2>/dev/null || echo "000")
    if [[ $app_status == "200" ]]; then
        print_status "App Health: OK"
    elif [[ $app_status == "404" ]]; then
        print_info "App Health: Endpoint not configured"
    else
        print_warning "App Health: $app_status"
    fi
    
    echo ""
}

check_database() {
    echo "=== Database Status ==="
    
    # Database connection test
    if sudo -u postgres psql -d crypto_airdrop_db -c "SELECT 1;" >/dev/null 2>&1; then
        print_status "Database: Connected"
        
        # Database size
        local db_size=$(sudo -u postgres psql -d crypto_airdrop_db -t -c "SELECT pg_size_pretty(pg_database_size('crypto_airdrop_db'));" | xargs)
        print_info "Database Size: $db_size"
        
        # Active connections
        local connections=$(sudo -u postgres psql -d crypto_airdrop_db -t -c "SELECT count(*) FROM pg_stat_activity WHERE datname='crypto_airdrop_db';" | xargs)
        print_info "Active Connections: $connections"
        
    else
        print_error "Database: Connection failed"
    fi
    
    echo ""
}

check_logs() {
    echo "=== Recent Log Analysis ==="
    
    # Application errors (last hour)
    local error_count=$(sudo tail -1000 /var/log/crypto-airdrop/error.log 2>/dev/null | grep "$(date '+%Y-%m-%d %H')" | wc -l || echo "0")
    if [[ $error_count -gt 10 ]]; then
        print_warning "App Errors (last hour): $error_count"
    elif [[ $error_count -gt 0 ]]; then
        print_info "App Errors (last hour): $error_count"
    else
        print_status "App Errors (last hour): $error_count"
    fi
    
    # Nginx errors (last hour)
    local nginx_errors=$(sudo tail -1000 /var/log/nginx/error.log 2>/dev/null | grep "$(date '+%Y/%m/%d %H')" | wc -l || echo "0")
    if [[ $nginx_errors -gt 5 ]]; then
        print_warning "Nginx Errors (last hour): $nginx_errors"
    elif [[ $nginx_errors -gt 0 ]]; then
        print_info "Nginx Errors (last hour): $nginx_errors"
    else
        print_status "Nginx Errors (last hour): $nginx_errors"
    fi
    
    echo ""
}

check_ssl() {
    echo "=== SSL Certificate Status ==="
    
    local cert_found=false
    for cert_dir in /etc/letsencrypt/live/*/; do
        if [[ -d "$cert_dir" && -f "${cert_dir}cert.pem" ]]; then
            cert_found=true
            local cert_file="${cert_dir}cert.pem"
            local domain=$(basename "$cert_dir")
            local expiry=$(openssl x509 -enddate -noout -in "$cert_file" | cut -d= -f2)
            local expiry_timestamp=$(date -d "$expiry" +%s)
            local current_timestamp=$(date +%s)
            local days_until_expiry=$(( (expiry_timestamp - current_timestamp) / 86400 ))
            
            if [[ $days_until_expiry -lt 30 ]]; then
                print_warning "SSL Certificate ($domain): Expires in $days_until_expiry days"
            else
                print_status "SSL Certificate ($domain): Valid for $days_until_expiry days"
            fi
            break
        fi
    done
    
    if [[ "$cert_found" == false ]]; then
        print_info "SSL Certificate: Not configured"
    fi
    
    echo ""
}

check_backups() {
    echo "=== Backup Status ==="
    
    # Check if backup directory exists
    if [[ -d /var/backups/${APP_NAME} ]]; then
        # Latest database backup
        local latest_db_backup=$(find /var/backups/${APP_NAME}/db -name "*.sql.gz" -type f -printf '%T@ %p\n' 2>/dev/null | sort -n | tail -1 | cut -d' ' -f2- || echo "")
        if [[ -n $latest_db_backup ]]; then
            local backup_age=$(( ($(date +%s) - $(stat -c %Y "$latest_db_backup")) / 86400 ))
            if [[ $backup_age -le 7 ]]; then
                print_status "Latest DB Backup: $backup_age days ago"
            else
                print_warning "Latest DB Backup: $backup_age days ago (Old)"
            fi
        else
            print_warning "Database Backup: None found"
        fi
        
        # Latest app backup
        local latest_app_backup=$(find /var/backups/${APP_NAME}/app -name "*.tar.gz" -type f -printf '%T@ %p\n' 2>/dev/null | sort -n | tail -1 | cut -d' ' -f2- || echo "")
        if [[ -n $latest_app_backup ]]; then
            local backup_age=$(( ($(date +%s) - $(stat -c %Y "$latest_app_backup")) / 86400 ))
            if [[ $backup_age -le 7 ]]; then
                print_status "Latest App Backup: $backup_age days ago"
            else
                print_warning "Latest App Backup: $backup_age days ago (Old)"
            fi
        else
            print_warning "Application Backup: None found"
        fi
    else
        print_error "Backup Directory: Not found"
    fi
    
    echo ""
}

generate_summary() {
    echo "=== Health Check Summary ==="
    
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    print_info "Health check completed at: $timestamp"
    
    # Count issues
    local warnings=$(grep -c "⚠" /tmp/health_check_output 2>/dev/null || echo "0")
    local errors=$(grep -c "✗" /tmp/health_check_output 2>/dev/null || echo "0")
    
    if [[ $errors -gt 0 ]]; then
        print_error "Found $errors critical issues"
    elif [[ $warnings -gt 0 ]]; then
        print_warning "Found $warnings warnings"
    else
        print_status "All systems healthy"
    fi
    
    echo ""
    echo "For detailed management commands, see: /root/deployment-info.txt"
}

main() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                     Crypto Airdrop Platform Health Check                    ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    
    # Create temporary file to capture output for summary
    exec > >(tee /tmp/health_check_output)
    
    check_system_resources
    check_services
    check_application
    check_network_connectivity
    check_database
    check_logs
    check_ssl
    check_backups
    generate_summary
    
    # Clean up temp file
    rm -f /tmp/health_check_output
}

main "$@"