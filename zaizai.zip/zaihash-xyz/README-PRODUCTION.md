# 🚀 One-Click Production VPS Setup

Complete automated production deployment for the Crypto Airdrop Platform on Ubuntu VPS.

## Quick Deploy (30 seconds)

```bash
# Download and run master setup
curl -sSL https://raw.githubusercontent.com/your-repo/main/setup-production.sh | sudo bash
```

Or step-by-step:

```bash
# 1. Clone repository
git clone https://github.com/your-repo/crypto-airdrop.git
cd crypto-airdrop

# 2. Run one-click setup
sudo ./setup-production.sh
```

## What Gets Installed & Configured

### System Components
- **Node.js 20** with npm and global packages (PM2, tsx)
- **PostgreSQL** with dedicated database and secure user
- **Nginx** with reverse proxy, rate limiting, and security headers
- **UFW Firewall** with production-ready rules
- **PM2** for process management and monitoring
- **Certbot** (optional) for SSL certificates

### Security Features
- Dedicated application user (www-data)
- Database with generated secure credentials
- Firewall blocking all unnecessary ports
- Rate limiting (10 req/s API, 30 req/s general)  
- Security headers (XSS, CSRF, Content-Type protection)
- File permissions locked down appropriately

### Monitoring & Maintenance
- Automated backups (weekly database and application)
- Log rotation to prevent disk space issues
- Health check system for monitoring
- Performance monitoring with PM2
- Systemd service for automatic startup

## File Structure After Setup

```
/var/www/crypto-airdrop/          # Main application
├── server/                       # Backend code
├── client/                       # Frontend code  
├── db/                          # Database files
├── .env                         # Environment variables
└── ecosystem.config.cjs         # PM2 configuration

/var/log/crypto-airdrop/         # Application logs
/var/backups/crypto-airdrop/     # Automated backups
/etc/nginx/sites-available/      # Web server config
/root/deployment-info.txt        # Setup credentials & info
```

## Management Commands

```bash
# Application Control
sudo systemctl start|stop|restart crypto-airdrop
sudo -u www-data pm2 restart crypto-airdrop
sudo -u www-data pm2 logs crypto-airdrop

# System Monitoring
sudo ./health-check.sh           # Complete system health
sudo crypto-airdrop-monitor.sh   # Detailed monitoring
sudo -u www-data pm2 monit       # Real-time metrics

# Maintenance
sudo crypto-airdrop-backup.sh    # Manual backup
sudo ./ssl-setup.sh domain.com email@domain.com  # SSL setup
```

## Access Your Application

After setup completes:
- **HTTP**: `http://your-server-ip`
- **Admin Panel**: Login with default credentials (change immediately)
- **Database**: Credentials in `/root/deployment-info.txt`

## SSL Setup (Optional)

```bash
sudo ./ssl-setup.sh yourdomain.com admin@yourdomain.com
```

Configures:
- Let's Encrypt SSL certificate
- Automatic renewal
- Enhanced security headers
- HTTPS redirect

## Production Optimizations

### Performance
- PM2 cluster mode with memory limits
- Nginx caching for static assets
- Database connection pooling
- Gzip compression enabled

### Reliability  
- Automatic process restart on failure
- Health check endpoints
- Log monitoring and rotation
- Database backup verification

### Security
- Non-root application execution
- Secure environment variable storage
- Rate limiting and DDoS protection
- Regular security header updates

## Troubleshooting

### Common Issues

**Application won't start:**
```bash
sudo -u www-data pm2 logs crypto-airdrop
sudo ./health-check.sh
```

**Database connection errors:**
```bash
sudo systemctl status postgresql
cat /var/www/crypto-airdrop/.env
```

**Nginx errors:**
```bash
sudo nginx -t
sudo systemctl status nginx
```

**Permission errors:**
```bash
sudo chown -R www-data:www-data /var/www/crypto-airdrop/
sudo chmod 600 /var/www/crypto-airdrop/.env
```

### Reset & Reinstall
```bash
# Stop services
sudo systemctl stop crypto-airdrop nginx

# Clean installation
sudo rm -rf /var/www/crypto-airdrop
sudo -u postgres dropdb crypto_airdrop_db

# Re-run setup
sudo ./setup-production.sh
```

## Architecture Overview

```
Internet → Nginx (Port 80/443) → Node.js App (Port 3000) → PostgreSQL (Port 5432)
                ↓
           Rate Limiting
           Security Headers  
           Static Caching
           SSL Termination
```

## Scaling Options

### Vertical Scaling
- Increase server RAM/CPU
- Adjust PM2 instance count
- Optimize database configuration

### Horizontal Scaling  
- Load balancer with multiple app servers
- Database replication
- CDN for static assets
- Redis for session sharing

## Backup & Recovery

### Automated Backups
- **Database**: Weekly PostgreSQL dumps
- **Application**: Weekly file archives
- **Retention**: 7 days (configurable)
- **Location**: `/var/backups/crypto-airdrop/`

### Manual Recovery
```bash
# Restore database
sudo -u postgres psql -d crypto_airdrop_db < backup.sql

# Restore application files
tar -xzf app_backup.tar.gz -C /var/www/crypto-airdrop/
sudo chown -R www-data:www-data /var/www/crypto-airdrop/
```

## Support & Maintenance

### Regular Tasks
- Monitor system resources weekly
- Review security logs monthly  
- Update system packages as needed
- Test backup restoration quarterly

### Key Files
- **Setup Info**: `/root/deployment-info.txt`
- **Environment**: `/var/www/crypto-airdrop/.env`
- **Logs**: `/var/log/crypto-airdrop/`
- **Nginx Config**: `/etc/nginx/sites-available/crypto-airdrop`

Your crypto airdrop platform is now production-ready with enterprise-grade security, monitoring, and automated maintenance systems.