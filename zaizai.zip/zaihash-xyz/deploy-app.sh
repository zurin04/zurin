#!/bin/bash

# Application Deployment Script for Crypto Airdrop Platform
# This script deploys the application after the production setup is complete

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
APP_NAME="crypto-airdrop"
APP_DIR="/var/www/${APP_NAME}"
SOURCE_DIR="$(pwd)"

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root. Use: sudo $0"
        exit 1
    fi
}

check_production_setup() {
    print_status "Checking production environment..."
    
    # Check if production setup was completed
    if [[ ! -f /root/deployment-info.txt ]]; then
        print_error "Production setup not found. Run ./production-setup.sh first"
        exit 1
    fi
    
    # Check required services
    if ! systemctl is-active --quiet postgresql; then
        print_error "PostgreSQL is not running"
        exit 1
    fi
    
    if ! systemctl is-active --quiet nginx; then
        print_error "Nginx is not running"
        exit 1
    fi
    
    # Check Node.js and PM2
    if ! command -v node &> /dev/null; then
        print_error "Node.js not found"
        exit 1
    fi
    
    if ! command -v pm2 &> /dev/null; then
        print_error "PM2 not found"
        exit 1
    fi
    
    print_status "Production environment verified"
}

copy_application_files() {
    print_status "Copying application files..."
    
    # Create backup of existing deployment if it exists
    if [[ -d ${APP_DIR}/server ]]; then
        print_status "Creating backup of existing deployment..."
        tar -czf /var/backups/${APP_NAME}/app/backup_$(date +%Y%m%d_%H%M%S).tar.gz -C ${APP_DIR} .
    fi
    
    # Copy application files (excluding development files)
    rsync -av --exclude='node_modules' \
              --exclude='.git' \
              --exclude='*.log' \
              --exclude='.env.local' \
              --exclude='dist' \
              ${SOURCE_DIR}/ ${APP_DIR}/
    
    # Set proper ownership
    chown -R www-data:www-data ${APP_DIR}
    chmod -R 755 ${APP_DIR}
    
    # Protect sensitive files
    if [[ -f ${APP_DIR}/.env ]]; then
        chmod 600 ${APP_DIR}/.env
    fi
    
    print_status "Application files copied successfully"
}

install_dependencies() {
    print_status "Installing Node.js dependencies..."
    
    cd ${APP_DIR}
    
    # Clear any existing node_modules
    if [[ -d node_modules ]]; then
        rm -rf node_modules
    fi
    
    # Install production dependencies
    sudo -u www-data npm ci --production --silent
    
    print_status "Dependencies installed successfully"
}

build_application() {
    print_status "Building application..."
    
    cd ${APP_DIR}
    
    # Install dev dependencies for build
    sudo -u www-data npm install --silent
    
    # Build the application
    sudo -u www-data npm run build
    
    # Remove dev dependencies after build
    sudo -u www-data npm prune --production
    
    print_status "Application built successfully"
}

setup_database() {
    print_status "Setting up database schema..."
    
    cd ${APP_DIR}
    
    # Push database schema
    sudo -u www-data npm run db:push
    
    # Seed database if seed file exists
    if [[ -f db/seed.ts ]]; then
        print_status "Seeding database..."
        sudo -u www-data npm run db:seed
    fi
    
    print_status "Database setup completed"
}

start_application() {
    print_status "Starting application..."
    
    cd ${APP_DIR}
    
    # Stop any existing PM2 processes
    sudo -u www-data pm2 delete crypto-airdrop 2>/dev/null || true
    
    # Start application with PM2
    sudo -u www-data pm2 start ecosystem.config.cjs
    
    # Save PM2 configuration
    sudo -u www-data pm2 save
    
    # Enable systemd service
    systemctl enable ${APP_NAME}
    systemctl start ${APP_NAME}
    
    print_status "Application started successfully"
}

verify_deployment() {
    print_status "Verifying deployment..."
    
    # Wait for application to start
    sleep 10
    
    # Check if application is running
    if sudo -u www-data pm2 list | grep -q "crypto-airdrop.*online"; then
        print_status "Application is running"
    else
        print_error "Application failed to start"
        sudo -u www-data pm2 logs crypto-airdrop --lines 20
        exit 1
    fi
    
    # Check if application responds
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 | grep -q "200\|302"; then
        print_status "Application is responding"
    else
        print_warning "Application may not be responding correctly"
    fi
    
    # Check Nginx proxy
    if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200\|302"; then
        print_status "Nginx proxy is working"
    else
        print_warning "Nginx proxy may have issues"
    fi
}

show_deployment_summary() {
    print_status "Deployment completed successfully!"
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                        🚀 Deployment Complete! 🚀                           ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Application Status:"
    sudo -u www-data pm2 list
    echo ""
    echo "Access your application:"
    echo "• Local: http://localhost"
    echo "• Server IP: http://$(curl -s ifconfig.me 2>/dev/null || echo 'YOUR_SERVER_IP')"
    echo ""
    echo "Management commands:"
    echo "• View logs: sudo -u www-data pm2 logs crypto-airdrop"
    echo "• Restart app: sudo -u www-data pm2 restart crypto-airdrop"
    echo "• System status: sudo crypto-airdrop-monitor.sh"
    echo "• Full info: cat /root/deployment-info.txt"
    echo ""
    echo "Security reminders:"
    echo "• Change admin password after first login"
    echo "• Setup SSL: sudo certbot --nginx"
    echo "• Review firewall: sudo ufw status"
}

main() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                   Crypto Airdrop Platform Deployment                        ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    
    check_root
    check_production_setup
    
    print_status "Starting application deployment..."
    
    copy_application_files
    install_dependencies
    build_application
    setup_database
    start_application
    verify_deployment
    show_deployment_summary
}

main "$@"