#!/bin/bash

# Ubuntu Server Deployment Script for Crypto Airdrop Platform
# Simple production deployment setup

set -e

# Variables
APP_NAME="crypto-airdrop"
APP_DIR="/var/www/${APP_NAME}"
DB_NAME="crypto_airdrop_db"
DB_USER="crypto_airdrop_user"
NGINX_CONF="/etc/nginx/sites-available/${APP_NAME}"

print_status() {
    echo "[INFO] $1"
}

print_error() {
    echo "[ERROR] $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

# Update system packages
print_status "Updating system packages..."
apt update && apt upgrade -y

# Install required packages
print_status "Installing required packages..."
apt install -y curl wget nginx postgresql postgresql-contrib

# Install Node.js 20
print_status "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Setup firewall
print_status "Setting up firewall..."
ufw allow 22
ufw allow 80
ufw allow 443
ufw --force enable

# Setup PostgreSQL
print_status "Setting up PostgreSQL..."
systemctl start postgresql
systemctl enable postgresql

# Generate random password for database user
DB_PASSWORD=$(openssl rand -base64 32)

# Create database and user
sudo -u postgres psql << EOF
CREATE DATABASE ${DB_NAME};
CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
ALTER USER ${DB_USER} CREATEDB;
\q
EOF

# Create application directory
print_status "Setting up application directory..."
mkdir -p ${APP_DIR}
chown -R www-data:www-data ${APP_DIR}
chmod -R 755 ${APP_DIR}

# Create Nginx configuration
print_status "Creating Nginx configuration..."
cat > ${NGINX_CONF} << 'EOF'
server {
    listen 80;
    server_name _;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline' 'unsafe-eval'" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/javascript
        application/xml+rss
        application/json
        application/xml
        image/svg+xml;
    
    # Main application
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }
    
    # WebSocket support
    location /ws {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # API endpoints
    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        proxy_pass http://127.0.0.1:3000;
    }
    
    # Health check endpoint
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF

# Enable Nginx site
ln -sf ${NGINX_CONF} /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test and start Nginx
print_status "Testing Nginx configuration..."
if nginx -t; then
    systemctl restart nginx
    systemctl enable nginx
    print_status "Nginx configured successfully"
else
    print_error "Nginx configuration test failed"
    exit 1
fi

# Create environment file template
print_status "Creating environment configuration..."
cat > ${APP_DIR}/.env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
SESSION_SECRET=$(openssl rand -base64 32)
EOF

chown www-data:www-data ${APP_DIR}/.env
chmod 600 ${APP_DIR}/.env

# Create deployment info file
print_status "Creating deployment information..."
cat > /root/deployment-info.txt << EOF
Crypto Airdrop Platform - Ubuntu Server Deployment
=================================================
Deployment Date: $(date)
Application Directory: ${APP_DIR}
Database: ${DB_NAME}
Database User: ${DB_USER}
Database Password: ${DB_PASSWORD}

Next Steps:
1. Copy your application files to ${APP_DIR}
2. Run: cd ${APP_DIR} && sudo -u www-data npm install --production
3. Run: sudo -u www-data npm run build
4. Run: sudo -u www-data npm run db:push
5. Run: sudo -u www-data npm run db:seed
6. Start application: sudo -u www-data npm start

Management Commands:
- View logs: journalctl -f
- Restart nginx: sudo systemctl restart nginx
- Database access: sudo -u postgres psql -d ${DB_NAME}

Security Notes:
- Change admin password after first login
- Setup SSL with Let's Encrypt: sudo certbot --nginx
- Review firewall rules: sudo ufw status

File Locations:
- App: ${APP_DIR}
- Nginx config: ${NGINX_CONF}
- Environment: ${APP_DIR}/.env
EOF

print_status "Deployment setup completed!"
print_status "Check /root/deployment-info.txt for next steps and credentials"
print_status "Your server is ready for application deployment"