#!/bin/bash

# Ubuntu Server Monitoring Script for Crypto Airdrop Platform
# This script monitors system health and application status

APP_NAME="crypto-airdrop"
APP_DIR="/var/www/${APP_NAME}"
LOG_FILE="/var/log/server-monitor.log"
ALERT_EMAIL=""  # Set your email for alerts

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a ${LOG_FILE}
}

check_system_resources() {
    log_message "Checking system resources..."
    
    # Check CPU usage
    CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
    if (( $(echo "$CPU_USAGE > 80" | bc -l) )); then
        log_message "WARNING: High CPU usage: ${CPU_USAGE}%"
    fi
    
    # Check memory usage
    MEMORY_USAGE=$(free | grep Mem | awk '{printf("%.2f", $3/$2 * 100.0)}')
    if (( $(echo "$MEMORY_USAGE > 80" | bc -l) )); then
        log_message "WARNING: High memory usage: ${MEMORY_USAGE}%"
    fi
    
    # Check disk space
    DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | cut -d'%' -f1)
    if [ "$DISK_USAGE" -gt 80 ]; then
        log_message "WARNING: High disk usage: ${DISK_USAGE}%"
    fi
    
    log_message "System resources: CPU: ${CPU_USAGE}%, Memory: ${MEMORY_USAGE}%, Disk: ${DISK_USAGE}%"
}

check_application_status() {
    log_message "Checking application status..."
    
    # Check systemd service
    if systemctl is-active --quiet ${APP_NAME}; then
        log_message "✓ Application service is running"
    else
        log_message "✗ Application service is not running"
        log_message "Attempting to restart application..."
        systemctl restart ${APP_NAME}
        sleep 10
        if systemctl is-active --quiet ${APP_NAME}; then
            log_message "✓ Application restarted successfully"
        else
            log_message "✗ Failed to restart application"
        fi
    fi
    
    # Check application health endpoint
    if curl -f http://localhost:3000/health >/dev/null 2>&1; then
        log_message "✓ Application health check passed"
    else
        log_message "✗ Application health check failed"
    fi
}

check_database_status() {
    log_message "Checking database status..."
    
    if systemctl is-active --quiet postgresql; then
        log_message "✓ PostgreSQL service is running"
        
        # Check if we can connect to the database
        if sudo -u postgres psql -d crypto_airdrop_db -c "SELECT 1;" >/dev/null 2>&1; then
            log_message "✓ Database connection successful"
        else
            log_message "✗ Database connection failed"
        fi
    else
        log_message "✗ PostgreSQL service is not running"
        log_message "Attempting to restart PostgreSQL..."
        systemctl restart postgresql
    fi
}

check_nginx_status() {
    log_message "Checking Nginx status..."
    
    if systemctl is-active --quiet nginx; then
        log_message "✓ Nginx service is running"
        
        # Test Nginx configuration
        if nginx -t >/dev/null 2>&1; then
            log_message "✓ Nginx configuration is valid"
        else
            log_message "✗ Nginx configuration has errors"
        fi
    else
        log_message "✗ Nginx service is not running"
        log_message "Attempting to restart Nginx..."
        systemctl restart nginx
    fi
}

check_ssl_certificate() {
    log_message "Checking SSL certificate..."
    
    # This will only work if SSL is configured
    CERT_FILE="/etc/letsencrypt/live/*/cert.pem"
    if ls ${CERT_FILE} >/dev/null 2>&1; then
        EXPIRY_DATE=$(openssl x509 -enddate -noout -in ${CERT_FILE} | cut -d= -f2)
        EXPIRY_TIMESTAMP=$(date -d "$EXPIRY_DATE" +%s)
        CURRENT_TIMESTAMP=$(date +%s)
        DAYS_UNTIL_EXPIRY=$(( (EXPIRY_TIMESTAMP - CURRENT_TIMESTAMP) / 86400 ))
        
        if [ "$DAYS_UNTIL_EXPIRY" -lt 30 ]; then
            log_message "WARNING: SSL certificate expires in ${DAYS_UNTIL_EXPIRY} days"
        else
            log_message "✓ SSL certificate is valid for ${DAYS_UNTIL_EXPIRY} days"
        fi
    else
        log_message "INFO: No SSL certificate found (HTTP only)"
    fi
}

cleanup_logs() {
    log_message "Cleaning up old logs..."
    
    # Clean PM2 logs older than 7 days
    find /var/log/pm2/ -name "*.log" -mtime +7 -delete 2>/dev/null || true
    
    # Clean application logs older than 30 days
    find /var/log/ -name "*${APP_NAME}*" -mtime +30 -delete 2>/dev/null || true
    
    # Rotate current monitor log if it's too large (>100MB)
    if [ -f "${LOG_FILE}" ] && [ $(stat -c%s "${LOG_FILE}") -gt 104857600 ]; then
        mv "${LOG_FILE}" "${LOG_FILE}.old"
        touch "${LOG_FILE}"
        log_message "Rotated monitor log file"
    fi
}

update_system_packages() {
    log_message "Checking for system updates..."
    
    # Update package list
    apt update >/dev/null 2>&1
    
    # Check for available updates
    UPDATES=$(apt list --upgradable 2>/dev/null | grep -c upgradable)
    if [ "$UPDATES" -gt 0 ]; then
        log_message "INFO: ${UPDATES} system updates available"
        
        # Auto-update security patches (optional)
        if [ "${AUTO_UPDATE:-false}" = "true" ]; then
            log_message "Applying security updates..."
            unattended-upgrade -d
        fi
    else
        log_message "✓ System is up to date"
    fi
}

backup_database() {
    log_message "Creating database backup..."
    
    BACKUP_DIR="/var/backups/crypto-airdrop/db"
    mkdir -p ${BACKUP_DIR}
    
    BACKUP_FILE="${BACKUP_DIR}/backup_$(date +%Y%m%d_%H%M%S).sql"
    
    if sudo -u postgres pg_dump crypto_airdrop_db > ${BACKUP_FILE}; then
        log_message "✓ Database backup created: ${BACKUP_FILE}"
        
        # Compress the backup
        gzip ${BACKUP_FILE}
        log_message "✓ Database backup compressed"
        
        # Clean old backups (keep only last 7 days)
        find ${BACKUP_DIR} -name "backup_*.sql.gz" -mtime +7 -delete
    else
        log_message "✗ Database backup failed"
    fi
}

# Main monitoring function
main() {
    log_message "=== Starting system monitoring ==="
    
    check_system_resources
    check_application_status
    check_database_status
    check_nginx_status
    check_ssl_certificate
    cleanup_logs
    
    # Run weekly tasks on Sundays
    if [ "$(date +%u)" -eq 7 ]; then
        update_system_packages
        backup_database
    fi
    
    log_message "=== Monitoring completed ==="
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root (use sudo)"
   exit 1
fi

# Run main function
main

# Exit with appropriate code
if grep -q "✗\|WARNING\|ERROR" ${LOG_FILE}; then
    exit 1
else
    exit 0
fi