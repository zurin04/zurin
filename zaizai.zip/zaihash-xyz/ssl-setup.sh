#!/bin/bash

# SSL Certificate Setup for Crypto Airdrop Platform
# This script sets up Let's Encrypt SSL certificates

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

APP_NAME="crypto-airdrop"

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root. Use: sudo $0"
        exit 1
    fi
}

install_certbot() {
    print_status "Installing Certbot..."
    
    # Install snapd if not present
    if ! command -v snap &> /dev/null; then
        apt update
        apt install -y snapd
        systemctl enable --now snapd.socket
        sleep 5
    fi
    
    # Install certbot via snap
    snap install core; snap refresh core
    snap install --classic certbot
    
    # Create symlink
    ln -sf /snap/bin/certbot /usr/bin/certbot
    
    print_status "Certbot installed successfully"
}

setup_ssl() {
    local domain=$1
    local email=$2
    
    print_status "Setting up SSL certificate for domain: $domain"
    
    # Backup current nginx config
    cp /etc/nginx/sites-available/${APP_NAME} /etc/nginx/sites-available/${APP_NAME}.backup
    
    # Update nginx config with domain
    sed -i "s/server_name _;/server_name $domain;/" /etc/nginx/sites-available/${APP_NAME}
    
    # Test nginx config
    if ! nginx -t; then
        print_error "Nginx configuration test failed"
        mv /etc/nginx/sites-available/${APP_NAME}.backup /etc/nginx/sites-available/${APP_NAME}
        exit 1
    fi
    
    # Reload nginx
    systemctl reload nginx
    
    # Obtain SSL certificate
    certbot --nginx -d $domain --email $email --agree-tos --non-interactive --redirect
    
    # Test SSL renewal
    certbot renew --dry-run
    
    print_status "SSL certificate setup completed for $domain"
}

create_ssl_renewal_service() {
    print_status "Setting up automatic SSL renewal..."
    
    # Create renewal script
    cat > /usr/local/bin/ssl-renewal.sh << 'EOF'
#!/bin/bash
certbot renew --quiet --post-hook "systemctl reload nginx"
EOF
    
    chmod +x /usr/local/bin/ssl-renewal.sh
    
    # Add to crontab for automatic renewal (twice daily)
    (crontab -l 2>/dev/null; echo "0 12,0 * * * /usr/local/bin/ssl-renewal.sh") | crontab -
    
    print_status "Automatic SSL renewal configured"
}

update_nginx_security() {
    print_status "Updating Nginx security configuration..."
    
    # Add SSL security headers to the nginx config
    cat > /etc/nginx/snippets/ssl-security.conf << 'EOF'
# SSL Security Configuration
ssl_protocols TLSv1.2 TLSv1.3;
ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;
ssl_prefer_server_ciphers off;
ssl_session_cache shared:SSL:10m;
ssl_session_timeout 10m;
ssl_stapling on;
ssl_stapling_verify on;

# Security headers
add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
EOF
    
    print_status "SSL security configuration created"
}

main() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                        SSL Certificate Setup                                ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    
    if [[ $# -lt 2 ]]; then
        echo "Usage: $0 <domain> <email>"
        echo "Example: $0 yourdomain.com admin@yourdomain.com"
        exit 1
    fi
    
    local domain=$1
    local email=$2
    
    check_root
    
    print_status "Setting up SSL for domain: $domain"
    print_status "Contact email: $email"
    echo ""
    
    install_certbot
    update_nginx_security
    setup_ssl $domain $email
    create_ssl_renewal_service
    
    print_status "SSL setup completed successfully!"
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                          🔒 SSL Enabled! 🔒                                 ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Your site is now secured with SSL:"
    echo "• HTTPS: https://$domain"
    echo "• Certificate auto-renewal configured"
    echo "• Enhanced security headers enabled"
    echo ""
    echo "SSL certificate will automatically renew every 60 days."
}

main "$@"