#!/bin/bash

# Comprehensive deployment validation script
set -e

LOG_FILE="/tmp/deployment-validation.log"
ERRORS=0

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

error() {
    echo "[ERROR] $1" | tee -a "$LOG_FILE"
    ERRORS=$((ERRORS + 1))
}

success() {
    echo "[✓] $1" | tee -a "$LOG_FILE"
}

warning() {
    echo "[⚠] $1" | tee -a "$LOG_FILE"
}

# Initialize log
echo "=== Deployment Validation Report ===" > "$LOG_FILE"
echo "Date: $(date)" >> "$LOG_FILE"
echo "=====================================" >> "$LOG_FILE"

log "Starting comprehensive deployment validation..."

# 1. System Requirements
log "Checking system requirements..."

# Node.js version
if command -v node >/dev/null 2>&1; then
    NODE_VERSION=$(node --version)
    success "Node.js installed: $NODE_VERSION"
else
    error "Node.js not installed"
fi

# PM2 installation
if command -v pm2 >/dev/null 2>&1; then
    PM2_VERSION=$(pm2 --version)
    success "PM2 installed: $PM2_VERSION"
else
    error "PM2 not installed"
fi

# tsx installation
if command -v tsx >/dev/null 2>&1; then
    TSX_VERSION=$(tsx --version)
    success "tsx installed: $TSX_VERSION"
else
    error "tsx not installed"
fi

# PostgreSQL
if command -v psql >/dev/null 2>&1; then
    success "PostgreSQL client available"
else
    error "PostgreSQL client not available"
fi

# Nginx
if command -v nginx >/dev/null 2>&1; then
    NGINX_VERSION=$(nginx -v 2>&1 | cut -d' ' -f3)
    success "Nginx installed: $NGINX_VERSION"
else
    error "Nginx not installed"
fi

# 2. Database connectivity
log "Testing database connectivity..."

if [ -n "$DATABASE_URL" ]; then
    if echo "SELECT 1;" | psql "$DATABASE_URL" >/dev/null 2>&1; then
        success "Database connection successful"
    else
        error "Database connection failed"
    fi
else
    error "DATABASE_URL not set"
fi

# 3. Application files
log "Checking application files..."

REQUIRED_FILES=(
    "server/index.ts"
    "package.json"
    "shared/schema.ts"
    "db/index.ts"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        success "Required file exists: $file"
    else
        error "Missing required file: $file"
    fi
done

# 4. PM2 configuration validation
log "Validating PM2 configuration..."

if [ -f "ecosystem.config.cjs" ]; then
    if node -e "require('./ecosystem.config.cjs')" >/dev/null 2>&1; then
        success "PM2 configuration syntax valid"
    else
        error "PM2 configuration has syntax errors"
    fi
else
    warning "PM2 configuration file not found (will be created during deployment)"
fi

# 5. Nginx configuration test
log "Testing Nginx configuration..."

if nginx -t >/dev/null 2>&1; then
    success "Nginx configuration valid"
else
    warning "Nginx configuration test failed (may need adjustment during deployment)"
fi

# 6. Port availability
log "Checking port availability..."

if ! netstat -tuln | grep -q ":5000 "; then
    success "Port 5000 available"
else
    warning "Port 5000 is in use"
fi

if ! netstat -tuln | grep -q ":80 "; then
    success "Port 80 available"
else
    warning "Port 80 is in use (may be nginx)"
fi

# 7. File permissions
log "Checking file permissions..."

if [ -w "." ]; then
    success "Application directory is writable"
else
    error "Application directory is not writable"
fi

# 8. Environment variables
log "Checking environment variables..."

REQUIRED_ENV_VARS=(
    "DATABASE_URL"
)

for var in "${REQUIRED_ENV_VARS[@]}"; do
    if [ -n "${!var}" ]; then
        success "Environment variable set: $var"
    else
        error "Missing environment variable: $var"
    fi
done

# 9. Dependencies check
log "Checking Node.js dependencies..."

if [ -f "package.json" ] && [ -d "node_modules" ]; then
    success "Node modules installed"
else
    warning "Node modules may need installation"
fi

# 10. Test application startup
log "Testing application startup..."

if timeout 10s npm run dev >/dev/null 2>&1 &
then
    sleep 5
    if curl -s http://localhost:5000 >/dev/null 2>&1; then
        success "Application starts and responds"
        pkill -f "npm run dev" || true
    else
        warning "Application starts but doesn't respond"
        pkill -f "npm run dev" || true
    fi
else
    error "Application failed to start"
fi

# Summary
log "=== Validation Summary ==="
log "Total errors: $ERRORS"

if [ $ERRORS -eq 0 ]; then
    success "All critical checks passed - deployment should succeed"
    exit 0
else
    error "Found $ERRORS critical issues - deployment may fail"
    log "Check the validation report at: $LOG_FILE"
    exit 1
fi