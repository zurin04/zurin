import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Set document title
document.title = "Crypto Airdrop Task Hub";

// Add meta description
const metaDescription = document.createElement('meta');
metaDescription.name = 'description';
metaDescription.content = 'Find the latest crypto airdrops, follow step-by-step tutorials, chat with the community, and track top crypto prices.';
document.head.appendChild(metaDescription);

createRoot(document.getElementById("root")!).render(<App />);
