# 🚀 One-Click Production Setup Guide

## Quick Start (2 Commands)

```bash
# 1. Download and run production setup
wget -O production-setup.sh https://raw.githubusercontent.com/your-repo/crypto-airdrop/main/production-setup.sh
sudo bash production-setup.sh

# 2. Deploy your application
sudo bash deploy-app.sh
```

Your crypto airdrop platform will be live at `http://your-server-ip`

## Complete Setup Process

### Prerequisites
- Fresh Ubuntu 20.04/22.04 LTS server
- Root access or sudo privileges
- Domain name (optional, for SSL)

### Step 1: Initial Server Setup
```bash
# Make scripts executable
chmod +x *.sh

# Run production environment setup
sudo ./production-setup.sh
```

This installs and configures:
- Node.js 20 with PM2 process manager
- PostgreSQL database with secure credentials
- Nginx web server with rate limiting
- UFW firewall with security rules
- Automated backups and monitoring
- Log rotation and system services

### Step 2: Deploy Application
```bash
# Deploy your application
sudo ./deploy-app.sh
```

This process:
- Copies application files to `/var/www/crypto-airdrop`
- Installs dependencies and builds the app
- Sets up database schema and seeds data
- Starts the application with PM2
- Verifies deployment success

### Step 3: SSL Setup (Optional)
```bash
# Setup SSL certificate with Let's Encrypt
sudo ./ssl-setup.sh yourdomain.com admin@yourdomain.com
```

## What Gets Installed

### System Components
- **Node.js 20**: Latest LTS version with npm
- **PM2**: Process manager for Node.js applications
- **PostgreSQL**: Database server with optimized configuration
- **Nginx**: Web server with reverse proxy and security headers
- **UFW**: Firewall with secure default rules
- **Certbot**: SSL certificate management (via ssl-setup.sh)

### Application Structure
```
/var/www/crypto-airdrop/          # Application directory
├── server/                       # Backend code
├── client/                       # Frontend code
├── db/                          # Database files
├── .env                         # Environment variables
├── ecosystem.config.cjs         # PM2 configuration
└── package.json                 # Dependencies

/var/log/crypto-airdrop/         # Application logs
├── error.log                    # Error logs
├── out.log                      # Output logs
└── combined.log                 # Combined logs

/etc/nginx/sites-available/      # Nginx configuration
└── crypto-airdrop               # Site configuration

/var/backups/crypto-airdrop/     # Automated backups
├── db/                          # Database backups
└── app/                         # Application backups
```

## Management Commands

### Application Management
```bash
# View application status
sudo -u www-data pm2 list

# View live logs
sudo -u www-data pm2 logs crypto-airdrop

# Restart application
sudo -u www-data pm2 restart crypto-airdrop

# Monitor resources
sudo -u www-data pm2 monit

# System service control
sudo systemctl start crypto-airdrop
sudo systemctl stop crypto-airdrop
sudo systemctl restart crypto-airdrop
sudo systemctl status crypto-airdrop
```

### Database Management
```bash
# Connect to database
sudo -u postgres psql -d crypto_airdrop_db

# Restart PostgreSQL
sudo systemctl restart postgresql

# View database logs
sudo journalctl -u postgresql
```

### Web Server Management
```bash
# Restart Nginx
sudo systemctl restart nginx

# Test Nginx configuration
sudo nginx -t

# Reload Nginx (without downtime)
sudo systemctl reload nginx

# View Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### System Monitoring
```bash
# Complete system status
sudo crypto-airdrop-monitor.sh

# View system resources
htop
df -h
free -h

# Check firewall status
sudo ufw status

# View system logs
sudo journalctl -f
```

### Backup & Maintenance
```bash
# Manual backup
sudo crypto-airdrop-backup.sh

# View backup files
ls -la /var/backups/crypto-airdrop/

# Restore from backup (database)
sudo -u postgres psql -d crypto_airdrop_db < backup.sql
```

## Default Credentials & Configuration

### Database Access
- **Host**: localhost
- **Port**: 5432
- **Database**: crypto_airdrop_db
- **Username**: crypto_user
- **Password**: Generated automatically (see `/root/deployment-info.txt`)

### Application Settings
- **Port**: 3000 (internal, proxied through Nginx)
- **Environment**: production
- **Session Secret**: Generated automatically
- **Log Level**: info

### Network Configuration
- **HTTP**: Port 80 (Nginx)
- **HTTPS**: Port 443 (after SSL setup)
- **SSH**: Port 22
- **Application**: Port 3000 (internal only)

## Security Features

### Firewall (UFW)
- Denies all incoming traffic by default
- Allows SSH (port 22), HTTP (80), HTTPS (443)
- Logs blocked connection attempts

### Nginx Security
- Rate limiting (10 requests/second for API, 30 for general)
- Security headers (XSS protection, content type sniffing protection)
- Request size limits (50MB max)
- Gzip compression enabled

### Application Security
- Secure session management with generated secrets
- Environment variables protected (600 permissions)
- Application runs as www-data user (non-root)
- Database credentials isolated per application

### SSL Security (After ssl-setup.sh)
- TLS 1.2/1.3 only
- Strong cipher suites
- HTTP Strict Transport Security (HSTS)
- Automatic certificate renewal

## Troubleshooting

### Application Won't Start
```bash
# Check PM2 status
sudo -u www-data pm2 list

# View error logs
sudo -u www-data pm2 logs crypto-airdrop --err

# Check environment variables
sudo -u www-data cat /var/www/crypto-airdrop/.env

# Verify file permissions
ls -la /var/www/crypto-airdrop/
```

### Database Connection Issues
```bash
# Test database connection
sudo -u postgres psql -d crypto_airdrop_db -c "SELECT 1;"

# Check PostgreSQL status
sudo systemctl status postgresql

# View PostgreSQL logs
sudo journalctl -u postgresql -f
```

### Nginx Issues
```bash
# Test configuration
sudo nginx -t

# Check Nginx status
sudo systemctl status nginx

# View error logs
sudo tail -f /var/log/nginx/error.log
```

### Permission Errors
```bash
# Fix application permissions
sudo chown -R www-data:www-data /var/www/crypto-airdrop/
sudo chmod -R 755 /var/www/crypto-airdrop/
sudo chmod 600 /var/www/crypto-airdrop/.env
```

## Performance Optimization

### Memory Management
- PM2 configured with 512MB memory limit
- Automatic restart on memory threshold
- Log rotation prevents disk space issues

### Caching
- Nginx caches static assets for 1 year
- Gzip compression for text content
- Browser caching headers optimized

### Database Optimization
- Connection pooling enabled
- Optimized PostgreSQL configuration
- Automated vacuum and analyze

## Monitoring & Alerts

### Built-in Monitoring
```bash
# System health check
sudo crypto-airdrop-monitor.sh

# Real-time resource monitoring
sudo -u www-data pm2 monit

# Log analysis
sudo tail -f /var/log/crypto-airdrop/combined.log
```

### Log Locations
- Application: `/var/log/crypto-airdrop/`
- Nginx: `/var/log/nginx/`
- System: `/var/log/syslog`
- PostgreSQL: `/var/log/postgresql/`

## Backup Strategy

### Automated Backups
- Database: Weekly automated dumps
- Application: Weekly file backups
- Retention: 7 days (configurable)
- Location: `/var/backups/crypto-airdrop/`

### Manual Backup
```bash
# Create immediate backup
sudo crypto-airdrop-backup.sh

# Backup specific components
sudo -u postgres pg_dump crypto_airdrop_db > manual_backup.sql
tar -czf app_backup.tar.gz -C /var/www/crypto-airdrop .
```

## Scaling & Performance

### Vertical Scaling
- Increase server resources (RAM, CPU)
- Adjust PM2 instance count in ecosystem.config.cjs
- Optimize PostgreSQL settings for larger datasets

### Horizontal Scaling
- Load balancer with multiple application servers
- Database replication for read queries
- CDN for static asset delivery
- Redis for session storage across instances

## Support & Maintenance

### Regular Tasks
- [ ] Monitor disk space weekly
- [ ] Review security logs monthly
- [ ] Update system packages monthly
- [ ] Test backup restoration quarterly
- [ ] Review SSL certificate expiration

### Getting Help
1. Check `/root/deployment-info.txt` for configuration details
2. Run `sudo crypto-airdrop-monitor.sh` for system status
3. Review application logs in `/var/log/crypto-airdrop/`
4. Test individual components (database, nginx, application)

Your crypto airdrop platform is now production-ready with enterprise-grade security, monitoring, and backup systems!