# Crypto Airdrop Platform - Deployment Guide

## Quick Ubuntu Server Setup

### Prerequisites
- Ubuntu 20.04+ server with root access
- At least 2GB RAM and 20GB disk space

### 1. Run the deployment script
```bash
# Download and run the setup script
sudo bash deploy.sh
```

This script will:
- Install Node.js 20, PostgreSQL, and Nginx
- Configure firewall (ports 22, 80, 443)
- Create database and user with secure credentials
- Set up Nginx reverse proxy configuration
- Create application directory structure

### 2. Deploy your application
```bash
# Copy your application files to the server
scp -r * user@server:/tmp/app-deploy/

# Move files and set proper permissions
sudo cp -r /tmp/app-deploy/* /var/www/crypto-airdrop/
sudo chown -R www-data:www-data /var/www/crypto-airdrop/
sudo chmod -R 755 /var/www/crypto-airdrop/

# Install dependencies and build
cd /var/www/crypto-airdrop
sudo -u www-data npm install --production
sudo -u www-data npm run build

# Setup database
sudo -u www-data npm run db:push
sudo -u www-data npm run db:seed
```

### 3. Start the application
```bash
# Start the application
sudo -u www-data npm start
```

Your application will be available at `http://your-server-ip`

### 4. Optional: Setup SSL
```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Get SSL certificate (replace your-domain.com)
sudo certbot --nginx -d your-domain.com
```

## Configuration Files

### Environment Variables
The script creates `/var/www/crypto-airdrop/.env` with:
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Secure session key
- `NODE_ENV=production`

### Nginx Configuration
Located at `/etc/nginx/sites-available/crypto-airdrop`
- Reverse proxy to port 3000
- WebSocket support
- Security headers
- Static file caching

## Management Commands

```bash
# View application logs
journalctl -f

# Restart Nginx
sudo systemctl restart nginx

# Access database
sudo -u postgres psql -d crypto_airdrop_db

# Check Nginx status
sudo systemctl status nginx

# Check firewall status
sudo ufw status
```

## Security Notes

1. Change the default admin password immediately after first login
2. Review and adjust firewall rules as needed
3. Setup SSL certificates for production use
4. Regularly update system packages
5. Monitor application logs for security issues

## Troubleshooting

### NPM Permission Errors (EACCES)
If you get "npm error code EACCES" when running npm commands:
```bash
# Fix file ownership and permissions
sudo chown -R www-data:www-data /var/www/crypto-airdrop/
sudo chmod -R 755 /var/www/crypto-airdrop/

# Clear npm cache if needed
sudo -u www-data npm cache clean --force

# Try the command again
sudo -u www-data npm install --production
```

### Nginx Configuration Issues
If you encounter the "invalid value 'must-revalidate'" error:
- The script now uses a simplified configuration without rate limiting
- Rate limiting zones must be configured in `/etc/nginx/nginx.conf`, not in site configs

### Database Connection Issues
- Check if PostgreSQL is running: `sudo systemctl status postgresql`
- Verify credentials in `/var/www/crypto-airdrop/.env`
- Check database exists: `sudo -u postgres psql -l`

### Application Won't Start
- Check Node.js version: `node --version` (should be 20.x)
- Verify all dependencies installed: `npm list`
- Check for build errors: `npm run build`
- Ensure proper file permissions: `ls -la /var/www/crypto-airdrop/`

## File Locations

- Application: `/var/www/crypto-airdrop/`
- Nginx config: `/etc/nginx/sites-available/crypto-airdrop`
- Environment file: `/var/www/crypto-airdrop/.env`
- Deployment info: `/root/deployment-info.txt`