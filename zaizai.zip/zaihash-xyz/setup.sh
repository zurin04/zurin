#!/bin/bash

# One-Click Production Setup
clear

echo "╔══════════════════════════════════════════════════════════════════════════════╗"
echo "║                    Crypto Airdrop Platform Setup                            ║"
echo "╚══════════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "This will install and configure everything needed for production:"
echo "- Node.js, PostgreSQL, Nginx, PM2"
echo "- Database setup with secure credentials"
echo "- Firewall and security configuration"
echo "- SSL-ready web server"
echo "- Complete application deployment"
echo ""

read -p "Continue with production setup? (y/N): " confirm

if [[ $confirm =~ ^[Yy]$ ]]; then
    if [ "$EUID" -ne 0 ]; then
        echo ""
        echo "Please run with sudo:"
        echo "sudo ./setup.sh"
        exit 1
    fi
    
    echo ""
    echo "Starting production deployment..."
    chmod +x scripts/one-click-deploy.sh
    ./scripts/one-click-deploy.sh
else
    echo "Setup cancelled."
    exit 0
fi