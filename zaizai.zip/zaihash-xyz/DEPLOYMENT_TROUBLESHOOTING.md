# PM2 Deployment Troubleshooting Guide

## Fixed PM2 Configuration Issues

### Problem: "module is not defined" Error
**Root Cause**: ES modules project using CommonJS PM2 configuration syntax
**Solution**: Use `.cjs` extension for PM2 configuration file

### Working PM2 Configuration

```javascript
// ecosystem.config.cjs (CORRECT)
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'tsx',
    args: 'server/index.ts',
    cwd: '/var/www/crypto-airdrop',
    interpreter: 'node',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: 'postgresql://user:pass@localhost:5432/db'
    },
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    time: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s'
  }]
};
```

### Deployment Commands That Work

```bash
# Install PM2 and tsx globally
npm install -g pm2@latest tsx

# Start application
pm2 start ecosystem.config.cjs

# Save PM2 configuration
pm2 save

# Check status
pm2 status

# View logs
pm2 logs crypto-airdrop
```

## Common Deployment Issues & Solutions

### 1. "No script path" Error
**Cause**: Missing or incorrect script path in PM2 config
**Fix**: Ensure `script: 'tsx'` and `args: 'server/index.ts'` are correct

### 2. Database Connection Errors
**Cause**: Missing DATABASE_URL environment variable
**Fix**: Verify DATABASE_URL is set in PM2 environment configuration

### 3. Build Timeout Issues
**Cause**: Large dependency tree (especially Lucide React icons)
**Fix**: Skip frontend build and run with tsx directly in production

### 4. Permission Errors
**Cause**: Incorrect file ownership
**Fix**: 
```bash
chown -R www-data:www-data /var/www/crypto-airdrop
chmod -R 755 /var/www/crypto-airdrop
```

### 5. Port Already in Use
**Cause**: Another process using port 5000
**Fix**: 
```bash
# Kill process on port 5000
sudo fuser -k 5000/tcp
# Or change port in PM2 config
```

### 6. Nginx Configuration Error
**Cause**: `limit_req_zone` directive in wrong location
**Fix**: Move rate limiting configuration to main nginx.conf http block
```bash
# Edit /etc/nginx/nginx.conf
# Add inside http block:
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
```

### 7. Nginx Test Failures
**Cause**: Invalid nginx configuration syntax
**Fix**: The deployment script now includes automatic error recovery:
- Tests configuration before applying
- Removes problematic directives if needed
- Restores backup configuration on failure

## Verification Steps

### 1. Test PM2 Configuration Syntax
```bash
node -e "require('./ecosystem.config.cjs')"
```

### 2. Test Database Connection
```bash
psql $DATABASE_URL -c "SELECT 1;"
```

### 3. Test Application Start
```bash
NODE_ENV=production tsx server/index.ts
```

### 4. Test Full PM2 Deployment
```bash
pm2 start ecosystem.config.cjs
pm2 logs --lines 20
curl http://localhost:5000
```

## Production Deployment Checklist

- [ ] PostgreSQL database created and accessible
- [ ] DATABASE_URL environment variable set
- [ ] Node.js 20+ installed
- [ ] PM2 installed globally
- [ ] tsx installed globally
- [ ] Application files in /var/www/crypto-airdrop
- [ ] Correct file permissions (www-data:www-data)
- [ ] ecosystem.config.cjs file created
- [ ] Nginx configuration active
- [ ] SSL certificate configured (optional)
- [ ] Firewall rules configured
- [ ] PM2 startup script configured

## Quick Deployment Test

Run this script to verify deployment readiness:

```bash
#!/bin/bash
echo "Testing deployment environment..."

# Check Node.js version
node --version || echo "❌ Node.js not installed"

# Check PM2
pm2 --version || echo "❌ PM2 not installed"

# Check tsx
tsx --version || echo "❌ tsx not installed"

# Check database
echo "SELECT 1;" | psql $DATABASE_URL || echo "❌ Database connection failed"

# Check application files
[ -f "server/index.ts" ] && echo "✅ Server file found" || echo "❌ Server file missing"

# Check PM2 config
[ -f "ecosystem.config.cjs" ] && echo "✅ PM2 config found" || echo "❌ PM2 config missing"

echo "Deployment test complete"
```

## Emergency Recovery

If deployment fails completely:

1. **Stop all PM2 processes**:
   ```bash
   pm2 kill
   ```

2. **Manual application start**:
   ```bash
   cd /var/www/crypto-airdrop
   NODE_ENV=production PORT=5000 tsx server/index.ts
   ```

3. **Check logs**:
   ```bash
   tail -f /var/log/pm2/crypto-airdrop*.log
   ```

4. **Reset PM2**:
   ```bash
   pm2 kill
   pm2 resurrect
   ```

## Success Indicators

When deployment is working correctly:

- `pm2 status` shows app as "online"
- `curl http://localhost:5000` returns HTML response
- Database queries in logs show successful connections
- No error messages in PM2 logs
- Nginx proxy passes requests successfully

The deployment script has been updated with all these fixes and should now work reliably for one-click deployment.