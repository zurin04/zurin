#!/bin/bash

# Fix npm permissions issues for deployment
# Run this if you encounter EACCES errors

APP_DIR="/var/www/crypto-airdrop"

echo "Fixing file permissions for npm operations..."

# Ensure the directory exists
if [ ! -d "$APP_DIR" ]; then
    echo "Creating application directory..."
    sudo mkdir -p "$APP_DIR"
fi

# Fix ownership and permissions
echo "Setting proper ownership..."
sudo chown -R www-data:www-data "$APP_DIR"

echo "Setting proper permissions..."
sudo chmod -R 755 "$APP_DIR"

# Fix npm cache permissions if it exists
if [ -d "/var/www/.npm" ]; then
    echo "Fixing npm cache permissions..."
    sudo chown -R www-data:www-data /var/www/.npm
    sudo chmod -R 755 /var/www/.npm
fi

# Clear npm cache
echo "Clearing npm cache..."
sudo -u www-data npm cache clean --force 2>/dev/null || true

echo "Permissions fixed. You can now run npm commands with:"
echo "  sudo -u www-data npm install --production"
echo "  sudo -u www-data npm run build"