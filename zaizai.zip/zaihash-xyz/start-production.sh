#!/bin/bash

# Production start script for Crypto Airdrop Platform
# This script starts the application in production mode

set -e

APP_DIR="/var/www/crypto-airdrop"
LOG_DIR="/var/log/crypto-airdrop"

print_status() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Create log directory
mkdir -p ${LOG_DIR}
chown www-data:www-data ${LOG_DIR}

# Change to application directory
cd ${APP_DIR}

print_status "Starting Crypto Airdrop Platform in production mode..."

# Fix permissions if needed
print_status "Checking and fixing file permissions..."
chown -R www-data:www-data ${APP_DIR}
chmod -R 755 ${APP_DIR}

# Check if .env file exists
if [ ! -f .env ]; then
    echo "Error: .env file not found in ${APP_DIR}"
    echo "Please run the deployment script first"
    exit 1
fi

# Check if node_modules exists
if [ ! -d node_modules ]; then
    echo "Error: node_modules not found. Please run 'npm install --production' first"
    exit 1
fi

# Check if build exists
if [ ! -d dist ]; then
    echo "Warning: dist directory not found. Running build..."
    sudo -u www-data npm run build
fi

# Start the application
print_status "Starting application on port 3000..."
exec sudo -u www-data node server/index.js >> ${LOG_DIR}/app.log 2>&1